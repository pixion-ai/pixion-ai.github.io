// 다나와 상품 상세/가격비교 페이지(prod.danawa.com/info/?pcode=...)에서 "쇼핑몰별 최저가" 목록을 뽑아내는
// 2단계 추출 스크립트. extractor_danawa.js(검색결과 페이지, 모델당 대표가 1건만 줌)가 준 링크로 한 번 더
// 들어가서 실제 판매처별 가격을 얻음 — background.js 의 danawaExpandDetail 이 호출함.
//
// 대상 DOM 구조:
//   <div class="box__mall-price"> ... <ul class="list__mall-price">
//     <li class="list-item">
//       <div class="box__logo">(<img alt="11번가">  또는  <span class="text__logo">G마켓</span>  또는  그냥 텍스트)</div>
//       <div class="box__price ..."><span class="text__num">517,640</span><span class="text__unit">원</span></div>
//       ...배송비/할부 안내...
//       <a class="link__full-cover" href="...">
//     </li>
//     ...
//   </ul></div>
// 판매처명 표시 방식이 판매처마다 달라서(이미지 alt / span 텍스트 / 그냥 <font><b> 텍스트) 세 가지를 순서대로 시도함.
// 링크(a.link__full-cover)는 다나와의 클릭 추적용 리디렉션(bridge/loadingBridge.html)이지만, 여기서는 문제
// 없음 — extractor_danawa.js 의 검색결과 링크와 달리 우리가 스크립트로 더 들어갈 게 아니라 보고서에서
// 사용자가 직접 눌러서 보는 용도라, 실제 판매처로 정상적으로 이동함.

(() => {
  const url = location.href;
  const bodyText = (document.body && document.body.innerText) || "";

  // --- 차단/캡차 감지 (extractor_danawa.js 와 동일한 추정 문구) ---
  if (/captcha/i.test(url) || /보안\s*문자|자동입력\s*방지/.test(bodyText)) {
    return { ok: false, blocked: true, blockType: "captcha", url, note: "캡차/보안 확인 페이지로 보임 (미검증)" };
  }
  if (/비정상적인\s*접근|일시적으로\s*제한/.test(bodyText)) {
    return { ok: false, blocked: true, blockType: "restricted", url, note: "다나와 접속 제한 페이지로 보임 (미검증)" };
  }

  const toInt = (v) => { const n = parseInt(String(v).replace(/[^\d]/g, ""), 10); return isNaN(n) ? null : n; };

  const rows = document.querySelectorAll("ul.list__mall-price > li.list-item");
  if (!rows.length) {
    return { ok: false, blocked: false, url, source: "DOM(상세)", count: 0, items: [],
             note: "'쇼핑몰별 최저가' 목록(ul.list__mall-price)을 못 찾음 (페이지 구조가 바뀌었을 수 있음)" };
  }

  const items = [];
  rows.forEach((li) => {
    const priceEl = li.querySelector(".box__price .text__num");
    const price = priceEl ? toInt(priceEl.textContent) : null;
    if (!price) return;
    const logo = li.querySelector(".box__logo");
    const mallImg = logo && logo.querySelector("img[alt]");
    const mallSpan = logo && logo.querySelector(".text__logo");
    const mall = ((mallImg && mallImg.alt) || (mallSpan && mallSpan.textContent) || (logo && logo.textContent) || "").trim();
    if (!mall) return;
    const a = li.querySelector("a.link__full-cover") || li.querySelector("a[href]");
    items.push({ name: "", price, mall, link: a ? a.href : url, kind: "danawa-detail" });
  });

  return { ok: items.length > 0, blocked: false, url, source: "DOM(상세)", count: items.length, items,
           note: items.length ? "" : "'쇼핑몰별 최저가' 목록은 찾았지만 개별 행을 못 뽑음 (페이지 구조 확인 필요)" };
})();
