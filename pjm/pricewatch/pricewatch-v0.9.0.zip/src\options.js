const FIELDS = ["sheetUrl", "brand", "excludeWords", "tabMode", "delayMs", "maxRetries"];
const DEFAULTS = {
  sheetUrl: "", brand: "비비텍", tabMode: "reuseHidden", delayMs: 1000, maxRetries: 3, retryWaitMs: 4 * 60 * 1000,
  accessoryPriceRatio: 0.5,
  excludeWords: "중고, 리퍼, 램프, 리모컨, 리모콘, 렌즈, 마운트, 브라켓, 브래킷, 케이스, 가방, 필터, 스크린, 케이블, 천장, 거치대, 부품, 교체용, 호환, 렌탈, 대여, 약정, 리스",
};

// background.js 가 실제로 쪼개는 방식과 똑같이 세야 함(쉼표/줄바꿈 구분, 빈 항목 제외)
const countExcludeWords = (text) => text.split(/[,\n]/).map((s) => s.trim()).filter(Boolean).length;
const updateExcludeCount = () => {
  document.getElementById("excludeCount").textContent = `(${countExcludeWords(document.getElementById("excludeWords").value)}개)`;
};
document.getElementById("excludeWords").addEventListener("input", updateExcludeCount);

chrome.storage.sync.get(DEFAULTS).then((s) => {
  FIELDS.forEach((f) => (document.getElementById(f).value = s[f] ?? DEFAULTS[f]));
  document.getElementById("retryWaitMin").value = Math.round((s.retryWaitMs ?? DEFAULTS.retryWaitMs) / 60000);
  document.getElementById("accessoryRatioPct").value = Math.round((s.accessoryPriceRatio ?? DEFAULTS.accessoryPriceRatio) * 100);
  updateExcludeCount();
});

document.getElementById("save").onclick = async () => {
  const s = {};
  FIELDS.forEach((f) => (s[f] = document.getElementById(f).value.trim()));
  s.delayMs = Number(s.delayMs) || 0;
  s.maxRetries = Number(s.maxRetries) || 0;
  s.retryWaitMs = (Number(document.getElementById("retryWaitMin").value) || 4) * 60000;
  const pct = Number(document.getElementById("accessoryRatioPct").value);
  s.accessoryPriceRatio = Number.isFinite(pct) ? pct / 100 : 0.5; // 0%도 유효한 값이라 || 로 처리하면 안 됨
  await chrome.storage.sync.set(s);
  const el = document.getElementById("saved");
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 1500);
};

document.getElementById("version").textContent = "Pixion Inc. 최저가 감시 · v" + chrome.runtime.getManifest().version;
