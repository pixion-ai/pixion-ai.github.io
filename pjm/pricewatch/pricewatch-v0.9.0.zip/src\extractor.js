// 네이버 쇼핑 검색 결과 페이지에서 상품 목록을 뽑아내는 스크립트.
// background.js 가 chrome.scripting.executeScript 로 주입하고, 마지막 표현식(IIFE 반환값)을 받습니다.
//
// 1순위: 페이지에 심어진 __NEXT_DATA__ JSON (구조가 바뀌어도 키 이름만 맞으면 동작)
// 2순위: DOM 셀렉터 (클래스명 일부 매칭 - 네이버가 해시 접미사를 붙이므로 부분 일치 사용)
//
// ※ 유지보수 포인트: 네이버가 페이지 구조를 바꾸면 여기의 KEYS / DOM 셀렉터를 수정하면 됩니다.

(() => {
  const url = location.href;
  const bodyText = (document.body && document.body.innerText) || "";

  // --- 차단/캡차 감지 ---
  // captcha: 그 탭에서 사용자가 직접 풀면 넘어가는 유형 (보안 확인, 자동입력 방지)
  // restricted: 네이버가 네트워크 단위로 접속 자체를 일시 차단한 유형 — 그 자리에서 풀 방법이 없고 시간이 지나야 풀림
  if (/captcha/i.test(url) || /보안\s*확인|자동입력\s*방지/.test(bodyText)) {
    return { ok: false, blocked: true, blockType: "captcha", url, note: "캡차/보안 확인 페이지로 보임" };
  }
  if (/비정상적인\s*접근|접속이\s*일시적으로\s*제한/.test(bodyText)) {
    return { ok: false, blocked: true, blockType: "restricted", url, note: "네이버 쇼핑 접속 제한 페이지로 보임" };
  }

  const KEYS = {
    name: ["productTitle", "productName", "title", "name"],
    price: ["lowPrice", "price", "mobileLowPrice", "salePrice"],
    mall: ["mallName", "mallNameOrg", "mallNm"],
    link: ["mallProductUrl", "crUrl", "productUrl", "adcrUrl", "link", "url"],
  };
  const pick = (o, keys) => { for (const k of keys) if (o[k] != null && o[k] !== "") return o[k]; return null; };
  const toInt = (v) => { const n = parseInt(String(v).replace(/[^\d]/g, ""), 10); return isNaN(n) ? null : n; };

  // --- 1. __NEXT_DATA__ 탐색 ---
  const items = [];
  const seen = new Set();
  const push = (it) => {
    if (!it.name || !it.price) return;
    const key = (it.link || "") + "|" + it.name + "|" + it.price;
    if (seen.has(key)) return;
    seen.add(key);
    items.push(it);
  };

  const walk = (node, depth) => {
    if (!node || typeof node !== "object" || depth > 30) return;
    if (Array.isArray(node)) { node.forEach((n) => walk(n, depth + 1)); return; }
    const name = pick(node, KEYS.name);
    const price = toInt(pick(node, KEYS.price));
    if (name && price && typeof name === "string") {
      const kind = node.productType != null ? String(node.productType) : "";
      const isCatalog = Array.isArray(node.lowMallList);
      const mallPrices = isCatalog ? node.lowMallList.map((m) => toInt(pick(m, KEYS.price))) : [];
      // 가격비교(카탈로그) 루트의 lowPrice 는 lowMallList 중 최저가를 그대로 요약한 값이라, 그 최저가
      // 판매처가 이미 lowMallList 에 펼쳐져 나온다면 루트를 또 넣으면 같은 상품을 두 번 세게 됨.
      // lowMallList 에 이 가격이 없을 때만(=목록이 비었거나 최저가가 목록에서 빠진 경우) 루트를 대신 넣음.
      if (!isCatalog || !mallPrices.includes(price)) {
        push({
          name, price,
          mall: pick(node, KEYS.mall) || (isCatalog ? "가격비교(카탈로그)" : ""),
          link: pick(node, KEYS.link) || "",
          kind,
          raw: { productType: node.productType, nvMid: node.nvMid || node.id || null },
        });
      }
      // 가격비교 상품에 딸린 판매처 목록. 개별 판매처가 자기만의 상품명을 갖고 있으면 그걸 쓰고
      // (그래야 판매처별로 제외어 필터가 따로 적용됨), 없으면 카탈로그 대표 상품명으로 대체.
      if (Array.isArray(node.lowMallList)) {
        node.lowMallList.forEach((m) => push({
          name: pick(m, KEYS.name) || name, price: toInt(pick(m, KEYS.price)),
          mall: pick(m, KEYS.mall) || "", link: pick(m, KEYS.link) || "", kind: "lowMall",
        }));
      }
    }
    for (const k in node) if (k !== "lowMallList") walk(node[k], depth + 1);
  };

  let source = "";
  const nd = document.getElementById("__NEXT_DATA__");
  if (nd) {
    try { walk(JSON.parse(nd.textContent), 0); source = "__NEXT_DATA__"; } catch (e) { /* fallthrough */ }
  }

  // --- 2. DOM fallback ---
  if (!items.length) {
    source = "DOM";
    const containers = document.querySelectorAll('[class*="product_item"], [class*="basicList_item"], li[class*="item"]');
    containers.forEach((el) => {
      const a = el.querySelector('a[class*="product_link"], a[class*="link"], a[title]');
      const priceEl = el.querySelector('[class*="price_num"], [class*="price"] em, [class*="price"] strong');
      const mallEl = el.querySelector('[class*="product_mall"], [class*="mall"] a, [class*="mall"]');
      const name = (a && (a.getAttribute("title") || a.textContent)) || "";
      const price = priceEl ? toInt(priceEl.textContent) : null;
      if (name && price) push({ name: name.trim(), price, mall: mallEl ? mallEl.textContent.trim() : "", link: a ? a.href : "", kind: "dom" });
    });
  }

  return { ok: items.length > 0, blocked: false, url, source, count: items.length, items,
           note: items.length ? "" : "상품을 찾지 못함 (페이지 구조 변경 가능성)" };
})();
