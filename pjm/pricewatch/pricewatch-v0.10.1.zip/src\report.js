import { buildCsv, buildExcludedCsv, buildDetailCsv, formatStamp, formatDuration, realPrice } from "./lib/report.js";
import { isPointBelow } from "./lib/match.js";

const won = (n) => (n == null ? "-" : Number(n).toLocaleString("ko-KR"));
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const link = (href, text) => (href ? `<a href="${esc(href)}" target="_blank" rel="noopener">${esc(text)}</a>` : esc(text));
// "가격비교(카탈로그)"/"다나와"는 실제 판매처 이름이 아니라 여러 판매처를 모은 집계 페이지라, 진짜 판매처와
// 구분되게 표시하고(회색 기울임 + 안내), 클릭하면 그 집계 페이지(=진짜 판매처가 나오는 곳)로 가도록 링크를 걺.
const AGGREGATE_MALLS = new Set(["가격비교(카탈로그)", "다나와"]);
const mallCell = (it) => {
  if (!it) return "-";
  const isAgg = AGGREGATE_MALLS.has(it.mall);
  const label = isAgg ? `${it.mall} ↗` : it.mall;
  return isAgg
    ? `<span class="mall-agg" title="개별 판매처가 아닌 집계 페이지입니다. 눌러서 실제 판매처를 확인하세요.">${link(it.link, label)}</span>`
    : link(it.link, it.mall);
};
// 판매가 칸: 가장 싼 경로의 가격 + 경로가 둘 이상이거나 네이버 묶음 가격이 섞였으면 경로별 가격을 작게 덧붙임
const priceCell = (it) => {
  const chs = it.prices || [];
  if (chs.length < 2 && !it.bundle) return won(it.price);
  // 사이트명과 가격을 한 줄에 붙여 씀 — 칸이 좁아 둘이 따로 접히면 세로로 길어져서 보기 나쁨
  const lines = chs.map((c) => `(${esc(c.site)}${c.bundle ? " 묶음" : ""}) ${won(c.price)}`).join("<br>");
  return `${won(it.price)}<div class="ch">${lines}</div>`;
};
// 포인트가 붙은 경로(네이버)의 링크 — 실질가는 그 경로에서 살 때 가격
const pointLink = (it) => ((it.prices || []).find((c) => c.price === it.pointPrice) || it).link;

document.getElementById("version").textContent = "Pixion Inc. 최저가 감시 · v" + chrome.runtime.getManifest().version;

const { lastReport: r } = await chrome.storage.local.get("lastReport");
if (!r) {
  document.getElementById("content").innerHTML = '<p class="muted">아직 생성된 보고서가 없습니다. 확장 아이콘을 눌러 "가격 조회 실행"을 눌러주세요.</p>';
} else {
  const s = r.summary;
  const modelCount = r.results.length < r.productCount ? `${r.results.length}/${r.productCount}개 모델 (중단됨)` : `${r.productCount}개 모델`;
  const stopNote = r.stopReason === "blocked" ? " · 접속 차단으로 중단"
    : r.stopReason === "cancelled" ? " · 사용자가 중단" : "";
  // 시트가 하나뿐이면(또는 시트 정보가 없는 옛 보고서면) "시트" 열은 군더더기라 숨김
  const sheetNames = [...new Set([...r.results, ...(r.skipped || [])].map((x) => x.sheet).filter(Boolean))];
  const multiSheet = sheetNames.length > 1;
  const sheetNote = multiSheet ? ` · 시트 ${sheetNames.length}개` : "";
  const rateNote = r.naverPayBaseRate != null ? ` · 포인트는 네이버페이 기본 적립 ${r.naverPayBaseRate}% 제외` : "";
  document.getElementById("meta").textContent =
    `${new Date(r.createdAt).toLocaleString("ko-KR")} 생성 · 브랜드 "${r.brand}"${sheetNote} · ${modelCount} · 소요시간 ${formatDuration(r.durationSec)}${rateNote}${stopNote}`;

  // 사이트별 차단 횟수(blockCounts)가 있으면 "네이버 1회" / "다나와 0회"를 줄바꿔서, 옛 보고서(그 필드 없음)는 합계만 표시
  const blockValue = r.blockCounts
    ? `<div class="block-lines">${Object.entries(r.blockCounts).map(([name, n]) => `<b>${esc(name)} ${n}회</b>`).join("")}</div>`
    : `<b>${r.blockCount || 0}회</b>`;
  const pointSellers = s.pointBelowSellerCount || 0;
  document.getElementById("cards").innerHTML = `
    <div class="card ${s.belowModelCount ? "alert" : ""}"><span>기준가 미만 발견 모델</span><b>${s.belowModelCount}</b></div>
    <div class="card ${s.belowSellerCount ? "alert" : ""}"><span>기준가 미만 판매처(건)</span><b>${s.belowSellerCount}</b></div>
    <div class="card ${pointSellers ? "point" : ""}"><span>포인트 반영 시 기준가 미만(건)</span><b>${pointSellers}</b></div>
    <div class="card"><span>조회 모델</span><b>${s.checked}</b></div>
    <div class="card"><span>매칭 상품 없음</span><b>${s.noDataCount}</b></div>
    <div class="card ${r.blockCount ? "alert" : ""}"><span>접속 거부(차단) 발생</span>${blockValue}</div>`;

  let html = "";

  // 모델별 현황 — 이 보고서의 핵심. 전체 모델을 한 줄씩, 시트에 있는 순서 그대로 보여주고
  // 기준가 미만(빨강) / 포인트 반영 시 기준가 미만(주황) / 제외어로 걸러졌지만 기준가 미만이었던 상품(회색)이 있는
  // 행을 누르면 그 모델의 해당 목록이 바로 아래 펼쳐짐.
  const flaggedTotal = r.results.reduce((n, x) => n + (x.flaggedExcluded ? x.flaggedExcluded.length : 0), 0);
  const pointModels = s.pointBelowModelCount || 0;
  const anyExpandable = r.results.some((x) => x.below.length || (x.pointBelow || []).length || (x.flaggedExcluded && x.flaggedExcluded.length));
  html += `<section><h2>모델별 현황 <span class="count">(${r.results.length}개 중 기준가 미만 ${s.belowModelCount}개${pointModels ? `, 포인트 반영 시 미만 ${pointModels}개` : ""}${flaggedTotal ? `, 제외어 적용 ${flaggedTotal}건` : ""})</span>${anyExpandable ? '<button class="link-btn" id="toggleAll">전체 펼치기</button>' : ""}</h2>`;
  if (!s.belowModelCount && !pointModels && !flaggedTotal) html += '<div class="empty-ok">✓ 기준가 미만인 모델이 없습니다.</div>';
  html += `<div class="table-wrap"><table><tr>${multiSheet ? "<th>시트</th>" : ""}<th>구분</th><th>모델</th><th class="num">기준가</th><th class="num">최저가</th><th>판매처</th><th>상태</th><th>검색</th></tr>`;
  r.results.forEach((x, i) => {
    const isBelow = x.below.length > 0;
    const points = x.pointBelow || [];
    const hasPoint = points.length > 0;
    const flagged = x.flaggedExcluded || [];
    const hasFlagged = flagged.length > 0;
    const expandable = isBelow || hasPoint || hasFlagged;

    // filterItems 가 가격대로 부속품성 제외를 이미 걸러주므로, 여기 남는 제외 건은 대체로 진짜 제외 대상 —
    // 기준가 미만이 없을 때는 "이상 없음"을 우선 보여주고 제외어 적용 건수는 참고용 괄호로만 덧붙임.
    let state;
    if (isBelow || hasPoint) {
      state = [
        isBelow && `<span class="diff">기준가 미만 ${x.below.length}건</span>`,
        hasPoint && `<span class="pt-badge">포인트 반영 시 미만 ${points.length}건</span>`,
        hasFlagged && `<span class="note-badge">제외어 적용 ${flagged.length}건</span>`,
      ].filter(Boolean).join(" ");
    } else if (hasFlagged) {
      state = `이상 없음 <span class="note-badge">(제외어 적용 ${flagged.length}건)</span>`;
    } else {
      state = x.matched.length ? "이상 없음" : `<span class="muted">${esc(x.note || "매칭 상품 없음")}</span>`;
    }

    const rowClass = [expandable && "expandable", isBelow && "below", !isBelow && hasPoint && "pointed",
      !isBelow && !hasPoint && hasFlagged && "flagged"].filter(Boolean).join(" ");
    const searchLinks = (x.siteUrls || []).map((s2) => link(s2.url, s2.name)).join(" · ");
    html += `<tr class="${rowClass}" ${expandable ? `data-toggle="mrow-${i}"` : ""}>
      ${multiSheet ? `<td>${esc(x.sheet)}</td>` : ""}<td>${esc(x.group)}</td><td>${esc(x.model)}</td><td class="num">${won(x.basePrice)}</td>
      <td class="num">${x.lowest ? won(x.lowest.price) : "-"}</td><td>${mallCell(x.lowest)}</td>
      <td>${expandable ? '<span class="chevron">▸</span>' : ""}${state}</td>
      <td>${searchLinks}</td></tr>`;

    if (expandable) {
      let sub = "";
      if (isBelow) {
        sub += `<div class="sub-block"><div class="sub-label">기준가 미만 판매처</div><div class="table-wrap sub">
          <table><tr><th class="num">판매가</th><th class="num">차액</th><th>판매처</th><th>상품명</th></tr>
          ${x.below.map((it) => `<tr class="below"><td class="num">${priceCell(it)}</td><td class="num diff">${won(it.price - x.basePrice)}</td><td>${mallCell(it)}</td><td>${link(it.link, it.name)}</td></tr>`).join("")}
          </table></div></div>`;
      }
      if (hasPoint) {
        sub += `<div class="sub-block"><div class="sub-label point">포인트 반영 시 기준가 미만 — 판매가는 기준가 이상</div><div class="table-wrap sub point">
          <table><tr><th class="num">실질가</th><th class="num">차액</th><th>판매처</th><th>상품명</th></tr>
          ${points.map((it) => `<tr class="pointed"><td class="num">${won(realPrice(it))}<div class="ch">판매가 ${won(it.pointPrice ?? it.price)}<br>추가 포인트 ${won(it.point)}</div></td><td class="num diff-pt">${won(realPrice(it) - x.basePrice)}</td><td>${mallCell(it)}</td><td>${link(pointLink(it), it.name)}</td></tr>`).join("")}
          </table></div></div>`;
      }
      if (hasFlagged) {
        sub += `<div class="sub-block"><div class="sub-label note">제외어로 걸러짐 — 참고용</div><div class="table-wrap sub note">
          <table><tr><th class="num">판매가</th><th class="num">차액</th><th>제외 사유</th><th>상품명</th></tr>
          ${flagged.map((r2) => `<tr><td class="num">${won(r2.item.price)}</td><td class="num diff">${won(r2.item.price - x.basePrice)}</td><td class="muted">${esc(r2.reason)}</td><td>${link(r2.item.link, r2.item.name)}</td></tr>`).join("")}
          </table></div></div>`;
      }
      html += `<tr class="mrow-detail" id="mrow-${i}" hidden><td colspan="${multiSheet ? 8 : 7}">${sub}</td></tr>`;
    }
  });
  html += "</table></div></section>";

  // 모델별 상세(모델별 매칭 전체 목록, OK 상품까지 다 보임)는 위와 상당 부분 겹치는 정보라
  // 기본은 접어두고, 필요할 때만(매칭이 이상하다 싶을 때) 펼쳐서 보게 함.
  html += `<details class="collapsible"><summary>모델별 상세 <span class="count">(검색된 상품 전체 목록)</span></summary><div class="inner">`;
  for (const x of r.results) {
    html += `<details class="model"><summary>${multiSheet ? `${esc(x.sheet)} · ` : ""}<b>${esc(x.model)}</b>&nbsp; 매칭 ${x.matched.length}개 / 검색결과 ${x.totalFound}개 (제외 ${x.rejectedCount}) · 출처 ${esc(x.source || "-")}</summary>`;
    if (!x.matched.length) html += '<p class="muted">없음</p>';
    else {
      html += `<div class="table-wrap"><table><tr><th class="num">가격</th><th class="num">추가 포인트</th><th>판매처</th><th>상품명</th></tr>`;
      for (const it of x.matched) {
        const cls = it.price < x.basePrice ? "below" : isPointBelow(it, x.basePrice) ? "pointed" : "";
        const pt = it.point > 0 ? won(it.point) : it.point == null && it.bundle ? '<span class="muted" title="네이버 묶음 목록에서만 확인돼 포인트를 알 수 없습니다">확인 불가</span>' : "-";
        html += `<tr class="${cls}"><td class="num">${priceCell(it)}</td><td class="num">${pt}</td><td>${mallCell(it)}</td><td>${link(it.link, it.name)}</td></tr>`;
      }
      html += "</table></div>";
    }
    html += "</details>";
  }
  html += "</div></details>";

  // 시트에서 건너뛴 행 — 없으면 표시 안 함
  if (r.skipped && r.skipped.length) {
    html += `<section style="margin-top:30px"><h2>시트에서 건너뛴 행 <span class="count">(${r.skipped.length}개)</span></h2>`;
    html += `<div class="table-wrap"><table><tr>${multiSheet ? "<th>시트</th>" : ""}<th>행</th><th>내용</th><th>사유</th></tr>`;
    for (const k of r.skipped) html += `<tr>${multiSheet ? `<td>${esc(k.sheet)}</td>` : ""}<td>${k.row}</td><td>${esc(k.raw)}</td><td class="muted">${esc(k.reason)}</td></tr>`;
    html += "</table></div></section>";
  }

  document.getElementById("content").innerHTML = html;

  const expandableRows = () => document.querySelectorAll("#content tr.expandable");
  const setAllRows = (open) => {
    expandableRows().forEach((row) => {
      const d = document.getElementById(row.dataset.toggle);
      if (!d) return;
      d.hidden = !open;
      row.classList.toggle("open", open);
    });
  };
  const updateToggleAllLabel = () => {
    const btn = document.getElementById("toggleAll");
    if (!btn) return;
    const rows = Array.from(expandableRows());
    const allOpen = rows.length > 0 && rows.every((row) => {
      const d = document.getElementById(row.dataset.toggle);
      return d && !d.hidden;
    });
    btn.textContent = allOpen ? "전체 접기" : "전체 펼치기";
  };

  // 모델별 현황 행 클릭 -> 그 모델의 기준가 미만 판매처/제외어로 걸러진 상품 펼치기·접기
  document.getElementById("content").addEventListener("click", (e) => {
    if (e.target.closest("a")) return; // 링크(네이버/다나와 등) 클릭은 그냥 링크만 열리게, 행 토글은 안 함
    if (e.target.closest("#toggleAll")) {
      const opening = e.target.closest("#toggleAll").textContent !== "전체 접기";
      setAllRows(opening);
      updateToggleAllLabel();
      return;
    }
    const row = e.target.closest("tr[data-toggle]");
    if (!row) return;
    const detail = document.getElementById(row.dataset.toggle);
    if (!detail) return;
    detail.hidden = !detail.hidden;
    row.classList.toggle("open", !detail.hidden);
    updateToggleAllLabel();
  });

  document.getElementById("csv").onclick = async () => {
    // 원래 실행 때와 같은 3개 파일(기준가 미만/제외어 확인/모델별 상세)을 같은 규칙으로 재생성.
    // 폴더명은 "지금 다시 받는 시각"이 아니라 이 보고서가 실제로 생성됐던 시각(report.createdAt) 기준 —
    // 그래야 원래 실행 때 만들어졌을 폴더명과 같아져서 헷갈리지 않음.
    const stamp = formatStamp(new Date(r.createdAt));
    const folder = `pricewatch/${stamp}`;
    const files = [
      [`${folder}/기준가미만.csv`, buildCsv(r)],
      [`${folder}/제외어확인.csv`, buildExcludedCsv(r)],
      [`${folder}/모델별상세.csv`, buildDetailCsv(r)],
    ];
    for (const [filename, csv] of files) {
      await chrome.downloads.download({ url: "data:text/csv;charset=utf-8," + encodeURIComponent("﻿" + csv), filename, saveAs: false });
    }
  };
}
