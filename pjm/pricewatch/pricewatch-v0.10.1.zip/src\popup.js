const $ = (id) => document.getElementById(id);

function render(status = {}) {
  const running = !!status.running;
  $("run").disabled = running;
  $("cancel").hidden = !running;
  const finished = status.phase === "완료" || status.phase === "중단됨";

  const sites = status.sites || {};
  const siteNames = Object.keys(sites);
  let text = "", pct = 0;

  if (status.error) {
    text = status.error;
  } else if (running && siteNames.length) {
    // 네이버/다나와가 각자 독립적으로 진행되니 사이트별로 한 줄씩 보여줌
    text = siteNames.map((name) => {
      const s = sites[name];
      if (s.error) return `${name}: ${s.error}`;
      return `${name}: ${s.phase || ""} ${s.done ?? 0}/${s.total ?? 0} ${s.current || ""}`.trim();
    }).join("\n");
    const pcts = siteNames.map((name) => (sites[name].total ? sites[name].done / sites[name].total : 0));
    pct = Math.round((pcts.reduce((a, b) => a + b, 0) / pcts.length) * 100);
  } else if (running) {
    text = `${status.phase || ""}\n${status.done}/${status.total} ${status.current || ""}`;
    pct = status.total ? Math.round((status.done / status.total) * 100) : 0;
  } else if (status.phase === "완료") {
    text = `완료 (${status.done}/${status.total}). 보고서 탭을 확인하세요.`;
    if (status.incompleteSites && status.incompleteSites.length) {
      text += `\n⚠ ${status.incompleteSites.join(", ")}: 차단으로 끝까지 못 갔습니다. 보고서에서 어디까지 됐는지 확인하세요.`;
    }
  } else if (status.phase === "중단됨") {
    // 네이버/다나와가 독립적으로 도니까, 합친 숫자(예: 45/45)만 보여주면 완료된 것처럼 헷갈릴 수 있음 —
    // 실제로 어느 조사가 어디까지 가다 끊겼는지 사이트별로 보여줌
    const perSite = siteNames.length
      ? siteNames.map((name) => `${name}: ${sites[name].phase || "중단됨"} (${sites[name].done ?? 0}/${sites[name].total ?? 0})`).join("\n")
      : `${status.done}/${status.total}까지 조회함`;
    text = `중단됨\n${perSite}\n이번 실행은 CSV/보고서를 만들지 않았습니다 (참고: "지난 보고서 열기"는 이전에 완료됐던 보고서입니다).`;
  } else {
    text = "버튼을 누르면 시트의 모델을 네이버 쇼핑/다나와에서 조회합니다.\n(네이버·다나와가 각자 탭에서 동시에 진행됩니다)";
  }

  $("prog").style.width = (running ? pct : finished ? 100 : 0) + "%";
  $("status").textContent = text;
  $("status").className = status.error ? "err" : "";
}

$("run").onclick = () => chrome.runtime.sendMessage({ type: "run" });
$("cancel").onclick = () => chrome.runtime.sendMessage({ type: "cancel" });
$("report").onclick = (e) => { e.preventDefault(); chrome.tabs.create({ url: chrome.runtime.getURL("src/report.html") }); };
$("opts").onclick = (e) => { e.preventDefault(); chrome.runtime.openOptionsPage(); };

chrome.runtime.onMessage.addListener((msg) => { if (msg.type === "status") render(msg.status); });
chrome.storage.local.get("status").then(({ status }) => render(status));
$("version").innerHTML = `<span class="company">Pixion Inc.</span> · v${chrome.runtime.getManifest().version}`;
