// 네이버 쇼핑 검색 결과 페이지에서 상품 목록을 뽑아내는 스크립트.
// background.js 가 chrome.scripting.executeScript 로 주입하고, 마지막 표현식(IIFE 반환값)을 받습니다.
//
// 1순위: 페이지에 심어진 __NEXT_DATA__ JSON (구조가 바뀌어도 키 이름만 맞으면 동작)
// 2순위: DOM 셀렉터 (클래스명 일부 매칭 - 네이버가 해시 접미사를 붙이므로 부분 일치 사용)
//
// ※ 유지보수 포인트: 네이버가 페이지 구조를 바꾸면 여기의 KEYS / DOM 셀렉터를 수정하면 됩니다.

(() => {
  const url = location.href;
  const bodyText = (document.body && document.body.innerText) || "";

  // --- 차단/캡차 감지 ---
  // captcha: 그 탭에서 사용자가 직접 풀면 넘어가는 유형 (보안 확인, 자동입력 방지)
  // restricted: 네이버가 네트워크 단위로 접속 자체를 일시 차단한 유형 — 그 자리에서 풀 방법이 없고 시간이 지나야 풀림
  if (/captcha/i.test(url) || /보안\s*확인|자동입력\s*방지/.test(bodyText)) {
    return { ok: false, blocked: true, blockType: "captcha", url, note: "캡차/보안 확인 페이지로 보임" };
  }
  if (/비정상적인\s*접근|접속이\s*일시적으로\s*제한/.test(bodyText)) {
    return { ok: false, blocked: true, blockType: "restricted", url, note: "네이버 쇼핑 접속 제한 페이지로 보임" };
  }

  const KEYS = {
    name: ["productTitle", "productName", "title", "name"],
    price: ["lowPrice", "price", "mobileLowPrice", "salePrice"],
    mall: ["mallName", "mallNameOrg", "mallNm"],
    link: ["mallProductUrl", "crUrl", "productUrl", "adcrUrl", "link", "url"],
  };
  const pick = (o, keys) => { for (const k of keys) if (o[k] != null && o[k] !== "") return o[k]; return null; };
  const toInt = (v) => { const n = parseInt(String(v).replace(/[^\d]/g, ""), 10); return isNaN(n) ? null : n; };

  // 최대 적립 포인트(원) = 구매 적립 금액 + 판매가 × 적립률(%).
  // buyPointContent 는 "8400^^0^0" 형태로 맨 앞 숫자가 구매 적립 금액(빈 값이면 없음),
  // naverPayAccumRto 는 적립률(%). 두 필드가 다 없으면 포인트를 알 수 없음(null).
  // 기본 적립률만큼 빼는 계산은 match.js 의 mergeSameListing 이 설정값으로 함.
  const pointOf = (node, price) => {
    const hasBuy = typeof node.buyPointContent === "string";
    const hasRto = node.naverPayAccumRto != null && node.naverPayAccumRto !== "";
    if (!hasBuy && !hasRto) return null;
    const buy = hasBuy ? (toInt(node.buyPointContent.split("^")[0]) || 0) : 0;
    const rto = Number(node.naverPayAccumRto) || 0;
    return buy + Math.floor((price * rto) / 100);
  };

  // --- 1. __NEXT_DATA__ 탐색 ---
  const items = [];
  const seen = new Set();
  const push = (it) => {
    if (!it.name || !it.price) return;
    // 같은 가격비교 묶음 안의 판매처들은 상품명·링크가 같아서, 판매처명까지 키에 넣어야 같은 가격의 다른 판매처가 안 빠짐
    const key = [it.link || "", it.name, it.price, it.mall || ""].join("|");
    if (seen.has(key)) return;
    seen.add(key);
    items.push(it);
  };

  const walk = (node, depth) => {
    if (!node || typeof node !== "object" || depth > 30) return;
    if (Array.isArray(node)) { node.forEach((n) => walk(n, depth + 1)); return; }
    const name = pick(node, KEYS.name);
    const price = toInt(pick(node, KEYS.price));
    if (name && price && typeof name === "string") {
      const kind = node.productType != null ? String(node.productType) : "";
      const isCatalog = Array.isArray(node.lowMallList);
      const catalogLink = pick(node, KEYS.link) || "";
      const mallPrices = isCatalog ? node.lowMallList.map((m) => toInt(pick(m, KEYS.price))) : [];
      // 가격비교(카탈로그) 루트의 lowPrice 는 lowMallList 중 최저가를 그대로 요약한 값이라, 그 최저가
      // 판매처가 이미 lowMallList 에 펼쳐져 나온다면 루트를 또 넣으면 같은 상품을 두 번 세게 됨.
      // lowMallList 에 이 가격이 없을 때만(=목록이 비었거나 최저가가 목록에서 빠진 경우) 루트를 대신 넣음.
      // 루트는 여러 판매처의 요약이라 판매처별 포인트를 알 수 없음.
      if (!isCatalog || !mallPrices.includes(price)) {
        push({
          name, price,
          mall: pick(node, KEYS.mall) || (isCatalog ? "가격비교(카탈로그)" : ""),
          link: catalogLink,
          kind,
          pid: isCatalog || node.mallProductId == null ? null : String(node.mallProductId),
          pointTotal: isCatalog ? null : pointOf(node, price),
          nameFromSeller: !isCatalog, // 개별 상품명은 판매처가 붙인 것, 카탈로그 루트는 네이버 대표명
          // 카탈로그 id/묶음에 보인 판매처 수 — background 가 필요할 때 카탈로그 페이지를 한 번 더 열 때 씀
          catalogId: isCatalog ? String(node.id || node.nvMid || "") : null,
          bundleCount: isCatalog ? node.lowMallList.length : 0,
          raw: { productType: node.productType, nvMid: node.nvMid || node.id || null },
        });
      }
      // 가격비교 묶음 안의 판매처 목록(가장 싼 몇 곳만). 실제 항목은 {nvMid, mallSeq, mallPid, price, naverPay, name} 뿐이고
      // name 이 상품명이 아니라 판매처명임 — 상품명은 묶음 대표 상품명, 링크는 묶음(카탈로그) 링크를 씀.
      // mallPid 는 같은 판매처가 따로 올린 개별 상품의 mallProductId 와 같음. 판매처별 포인트 정보는 없음.
      if (isCatalog) {
        node.lowMallList.forEach((m) => push({
          name: pick(m, ["productTitle", "productName"]) || name,
          price: toInt(pick(m, KEYS.price)),
          mall: pick(m, KEYS.mall) || (typeof m.name === "string" ? m.name.trim() : ""),
          link: pick(m, KEYS.link) || catalogLink,
          kind: "lowMall",
          nameFromSeller: !!pick(m, ["productTitle", "productName"]), // 없으면 카탈로그 대표명을 빌려 쓴 것
          pid: m.mallPid == null ? null : String(m.mallPid),
          pointTotal: null,
          catalogId: String(node.id || node.nvMid || ""),
          bundleCount: node.lowMallList.length,
        }));
      }
    }
    for (const k in node) if (k !== "lowMallList") walk(node[k], depth + 1);
  };

  let source = "";
  const nd = document.getElementById("__NEXT_DATA__");
  if (nd) {
    try { walk(JSON.parse(nd.textContent), 0); source = "__NEXT_DATA__"; } catch (e) { /* fallthrough */ }
  }

  // --- 2. DOM fallback ---
  if (!items.length) {
    source = "DOM";
    const containers = document.querySelectorAll('[class*="product_item"], [class*="basicList_item"], li[class*="item"]');
    containers.forEach((el) => {
      const a = el.querySelector('a[class*="product_link"], a[class*="link"], a[title]');
      const priceEl = el.querySelector('[class*="price_num"], [class*="price"] em, [class*="price"] strong');
      const mallEl = el.querySelector('[class*="product_mall"], [class*="mall"] a, [class*="mall"]');
      const name = (a && (a.getAttribute("title") || a.textContent)) || "";
      const price = priceEl ? toInt(priceEl.textContent) : null;
      if (name && price) push({ name: name.trim(), price, mall: mallEl ? mallEl.textContent.trim() : "", link: a ? a.href : "", kind: "dom", pid: null, pointTotal: null, nameFromSeller: true });
    });
  }

  return { ok: items.length > 0, blocked: false, url, source, count: items.length, items,
           note: items.length ? "" : "상품을 찾지 못함 (페이지 구조 변경 가능성)" };
})();
