// 다나와 검색결과 페이지에서 상품 목록을 뽑아내는 스크립트.
// background.js 가 chrome.scripting.executeScript 로 주입하고, 마지막 표현식(IIFE 반환값)을 받습니다.
//
// 네이버와 달리 페이지에 __NEXT_DATA__ 같은 JSON 블록이 없어서 DOM만 사용합니다.
// 검색결과 화면은 모델당 "대표 최저가" 1개만 보여주고(네이버 가격비교 카탈로그와 비슷한 성격), 개별
// 판매처별 가격은 상세페이지(prod.danawa.com/info/?pcode=...)에서 extractor_danawa_detail.js 가 2단계로 뽑아옴.
//
// ※ 유지보수 포인트: 다나와가 페이지 구조를 바꾸면 여기의 DOM 셀렉터를 수정하면 됩니다.
// ※ 차단/캡차 감지 로직은 다나와에서 실제로 본 적 없이 네이버 문구를 참고해 방어적으로 넣은 것 — 실제 문구와
//   다를 수 있음. 실행 시 보고서 상세의 "출처" 와 매칭 수를 보고 셀렉터를 맞출 것.

(() => {
  const url = location.href;
  const bodyText = (document.body && document.body.innerText) || "";

  // --- 차단/캡차 감지 ---
  if (/captcha/i.test(url) || /보안\s*문자|자동입력\s*방지/.test(bodyText)) {
    return { ok: false, blocked: true, blockType: "captcha", url, note: "캡차/보안 확인 페이지로 보임 (미검증)" };
  }
  if (/비정상적인\s*접근|일시적으로\s*제한/.test(bodyText)) {
    return { ok: false, blocked: true, blockType: "restricted", url, note: "다나와 접속 제한 페이지로 보임 (미검증)" };
  }

  const toInt = (v) => { const n = parseInt(String(v).replace(/[^\d]/g, ""), 10); return isNaN(n) ? null : n; };
  const extractPcode = (href) => { const m = String(href || "").match(/[?&]pcode=(\d+)/); return m ? m[1] : null; };

  const items = [];
  document.querySelectorAll("li.prod_item").forEach((el) => {
    const nameEl = el.querySelector(".prod_name a");
    const priceEl = el.querySelector(".price_sect a strong");
    if (!nameEl || !priceEl) return;
    const price = toInt(priceEl.textContent);
    if (!price) return;
    const linkEl = el.querySelector(".price_sect a") || nameEl;
    const rawLink = linkEl ? linkEl.href : "";
    // .price_sect a 는 실제로는 "bridge/loadingBridge.html?...&pcode=...&..." 형태의 클릭 추적용 리디렉션
    // 링크라, 그대로 열면 최종적으로 외부 판매처 페이지로 튕겨나가서(host_permissions 밖 도메인이라 스크립트
    // 주입이 막힘) extractor_danawa_detail.js 의 2단계 확장이 실패함. 링크 안의 pcode 파라미터로 다나와
    // 자체 가격비교 페이지 URL을 직접 만들어 쓰면 광고 클릭 추적을 거치지 않고 그 페이지로 바로 갈 수 있고,
    // 보고서에서 사용자가 직접 눌렀을 때도 판매처 하나(광고)가 아니라 쇼핑몰별 전체 최저가를 보여줘서 더 나음.
    const pcode = extractPcode(rawLink) || extractPcode(nameEl.href);
    const link = pcode ? `https://prod.danawa.com/info/?pcode=${pcode}` : rawLink;
    items.push({
      name: nameEl.textContent.trim(),
      price,
      mall: "다나와",
      link,
      kind: "danawa",
      nameFromSeller: false, // 다나와 대표 상품명(판매처가 붙인 이름 아님)
    });
  });

  return { ok: items.length > 0, blocked: false, url, source: "DOM", count: items.length, items,
           note: items.length ? "" : "상품을 찾지 못함 (페이지 구조 변경 가능성)" };
})();
