// 네이버 가격비교(카탈로그) 페이지(search.shopping.naver.com/catalog/<id>)에서 판매처별 목록을 뽑아내는
// 2단계 추출 스크립트. 검색결과의 lowMallList 는 가장 싼 5곳만 주는데, 이 페이지는 판매처별 최저가 목록을
// 한 번에 10곳까지 주고 판매처마다 실제 링크와 상품번호(mallProductId)까지 있어서 더 정확함 —
// background.js 의 naverExpandCatalog 가 필요한 모델에만 열어서 호출함.
//
// 이 페이지에는 검색결과와 달리 __NEXT_DATA__ 가 없음. 데이터는 self.__next_f(Next.js RSC 페이로드) 조각들에
// 나뉘어 들어 있고, 그 안에 react-query 상태(JSON)가 통째로 박혀 있음. 조각을 다 이어붙인 뒤
// '{"state":{"mutations"' 로 시작하는 JSON 을 괄호 짝을 세어 잘라내서 파싱함.
//
// 쓰는 쿼리:
//   ["catalogProducts","lowestPriceProductsByMall",{...}] -> { totalCount, products: [{ productName, price, mallName,
//                                                             mallProductId, pcProductUrl, isNaverPay, ... }] }
//   ["catalogBuyBox", ...]                                -> { buyBoxProducts: [같은 모양] }  (대표 판매처, 목록에 없을 수 있어 같이 씀)
//   ["productBenefit", <상품id>, <가격>]                   -> { point: { purchase: {value}, review: {value}, ... } }
//     구매적립(purchase)만 씀 — 리뷰적립/멤버십은 판매처가 정하는 금액이 아님. 이 쿼리는 일부 판매처에만
//     있어서, 없는 판매처의 포인트는 0이 아니라 "알 수 없음"(null).

(() => {
  const url = location.href;
  const bodyText = (document.body && document.body.innerText) || "";

  if (/captcha/i.test(url) || /보안\s*확인|자동입력\s*방지/.test(bodyText)) {
    return { ok: false, blocked: true, blockType: "captcha", url, note: "캡차/보안 확인 페이지로 보임" };
  }
  if (/비정상적인\s*접근|접속이\s*일시적으로\s*제한/.test(bodyText)) {
    return { ok: false, blocked: true, blockType: "restricted", url, note: "네이버 쇼핑 접속 제한 페이지로 보임" };
  }

  const catalogId = (url.match(/\/catalog\/(\d+)/) || [])[1] || "";

  // 확장이 주입한 스크립트는 페이지의 JS 변수(self.__next_f)를 못 봄 — 크롬이 확장 스크립트를 페이지와
  // 분리된 공간(isolated world)에서 실행하기 때문. 콘솔에서는 같은 공간이라 보이지만 여기선 항상 비어 있음.
  // 그래서 그 값이 들어 있는 <script> 태그의 "글자"를 직접 읽어 문자열 조각을 꺼냄(태그 자체는 DOM이라 읽힘).
  const chunksFromScript = (text) => {
    const out = [];
    const re = /self\.__next_f\.push\(\[\s*\d+\s*,\s*"/g;
    let m;
    while ((m = re.exec(text))) {
      const start = re.lastIndex - 1; // 여는 따옴표 위치
      let i = start + 1, esc = false;
      for (; i < text.length; i++) {
        const c = text[i];
        if (esc) { esc = false; continue; }
        if (c === "\\") { esc = true; continue; }
        if (c === '"') break;
      }
      try { out.push(JSON.parse(text.slice(start, i + 1))); } catch (e) { /* 조각 하나쯤 실패해도 나머지로 진행 */ }
      re.lastIndex = i + 1;
    }
    return out;
  };
  const domChunks = [...document.querySelectorAll("script")]
    .filter((s) => !s.src && s.textContent && s.textContent.indexOf("__next_f") >= 0)
    .reduce((acc, s) => acc.concat(chunksFromScript(s.textContent)), []);
  const pageChunks = (typeof self !== "undefined" && Array.isArray(self.__next_f))
    ? self.__next_f.map((c) => (Array.isArray(c) && typeof c[1] === "string" ? c[1] : "")) : [];
  const flight = (domChunks.length ? domChunks : pageChunks).join("");

  // 문자열 안의 중괄호/따옴표는 세지 않도록 이스케이프까지 보면서 짝 맞는 지점을 찾음
  const parseAt = (start) => {
    let depth = 0, inStr = false, esc = false;
    for (let i = start; i < flight.length; i++) {
      const c = flight[i];
      if (inStr) {
        if (esc) esc = false;
        else if (c === "\\") esc = true;
        else if (c === '"') inStr = false;
        continue;
      }
      if (c === '"') inStr = true;
      else if (c === "{") depth++;
      else if (c === "}" && --depth === 0) {
        try { return JSON.parse(flight.slice(start, i + 1)); } catch (e) { return null; }
      }
    }
    return null;
  };

  const MARK = '{"state":{"mutations"';
  const queries = [];
  for (let i = flight.indexOf(MARK); i >= 0; i = flight.indexOf(MARK, i + 1)) {
    const parsed = parseAt(i);
    if (parsed && parsed.state && Array.isArray(parsed.state.queries)) queries.push(...parsed.state.queries);
  }
  if (!queries.length) {
    return { ok: false, blocked: false, url, source: "RSC(카탈로그)", count: 0, items: [],
             note: "카탈로그 페이지에서 판매처 데이터를 못 찾음 (페이지 구조가 바뀌었을 수 있음)" };
  }

  const dataOf = (q) => (q && q.state && q.state.data) || null;
  const keyOf = (q) => (Array.isArray(q && q.queryKey) ? q.queryKey : []);

  // 가격별 구매적립 포인트 — productBenefit 쿼리 키의 세 번째 값이 그 상품 가격
  const pointByPrice = new Map();
  for (const q of queries) {
    const key = keyOf(q);
    if (key[0] !== "productBenefit") continue;
    const d = dataOf(q);
    const purchase = d && d.point && d.point.purchase;
    const value = purchase && Number(purchase.value);
    const price = Number(key[2]);
    if (value > 0 && price > 0) pointByPrice.set(price, Math.max(pointByPrice.get(price) || 0, value));
  }

  const rows = [];
  let totalCount = 0;
  for (const q of queries) {
    const key = keyOf(q);
    const d = dataOf(q);
    if (!d) continue;
    if (key[0] === "catalogProducts" && key[1] === "lowestPriceProductsByMall" && Array.isArray(d.products)) {
      totalCount = Math.max(totalCount, Number(d.totalCount) || 0);
      rows.push(...d.products);
    } else if (key[0] === "catalogBuyBox" && Array.isArray(d.buyBoxProducts)) {
      rows.push(...d.buyBoxProducts);
    }
  }

  const toInt = (v) => { const n = parseInt(String(v).replace(/[^\d]/g, ""), 10); return isNaN(n) ? null : n; };
  const str = (v) => (typeof v === "string" && v && !v.startsWith("$") ? v : ""); // RSC 는 참조/undefined 를 "$..." 문자열로 넣음
  const items = [];
  const seen = new Set();
  for (const p of rows) {
    const price = toInt(p.price != null ? p.price : p.krwPrice);
    const mall = str(p.mallName);
    if (!price || !mall) continue;
    const pid = str(p.mallProductId) || null;
    const key = `${mall}|${pid || ""}|${price}`;
    if (seen.has(key)) continue;
    seen.add(key);
    items.push({
      name: str(p.productName),
      price,
      mall,
      link: str(p.pcProductUrl) || url,
      kind: "catalog",
      nameFromSeller: !!str(p.productName), // 판매처별 목록의 상품명은 판매처가 붙인 것
      pid,
      pointTotal: pointByPrice.has(price) ? pointByPrice.get(price) : null,
      catalogId,
    });
  }

  const partial = totalCount > items.length ? `판매처 ${totalCount}곳 중 ${items.length}곳만 페이지에 나옴` : "";
  return { ok: items.length > 0, blocked: false, url, source: "RSC(카탈로그)", count: items.length, items,
           note: items.length ? partial : "판매처 목록이 비어 있음 (페이지 구조 확인 필요)" };
})();
