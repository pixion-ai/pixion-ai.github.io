// 다나와 상품 상세/가격비교 페이지(prod.danawa.com/info/?pcode=...)에서 "쇼핑몰별 최저가" 목록을 뽑아내는
// 2단계 추출 스크립트. extractor_danawa.js(검색결과 페이지, 모델당 대표가 1건만 줌)가 준 링크로 한 번 더
// 들어가서 실제 판매처별 가격을 얻음 — background.js 의 danawaExpandDetail 이 호출함.
//
// 대상 DOM 구조:
//   <div class="box__mall-price"> ... <ul class="list__mall-price">
//     <li class="list-item">
//       <div class="box__logo">(<img alt="11번가">  또는  <span class="text__logo">G마켓</span>  또는  그냥 텍스트)</div>
//       <div class="box__price ..."><span class="text__num">517,640</span><span class="text__unit">원</span></div>
//       ...배송비/할부 안내...
//       <a class="link__full-cover" href="...">
//     </li>
//     ...
//   </ul></div>
// 판매처명 표시 방식이 판매처마다 달라서(이미지 alt / span 텍스트 / 그냥 <font><b> 텍스트) 세 가지를 순서대로 시도함.
// 링크(a.link__full-cover)는 다나와의 클릭 추적용 리디렉션(bridge/loadingBridge.html)이라 보고서에서 사용자가
// 눌러서 보는 용도로만 씀. 그 안의 link_pcode 파라미터가 판매처 상품번호라, match.js 가 네이버 쪽 같은 매물을
// 찾는 데 씀. 이 링크로 들어가면 다나와 경유 가격이 적용됨.
//
// 포인트는 뽑지 않음: 이 페이지의 "멤버십/카드결제 최대 혜택가"는 네이버페이 기본 적립·N+멤버십·카드 할인까지
// 섞인 값이라 판매처가 정한 포인트만 따로 알 수 없음.

(() => {
  const url = location.href;
  const bodyText = (document.body && document.body.innerText) || "";

  // --- 차단/캡차 감지 (extractor_danawa.js 와 동일한 추정 문구) ---
  if (/captcha/i.test(url) || /보안\s*문자|자동입력\s*방지/.test(bodyText)) {
    return { ok: false, blocked: true, blockType: "captcha", url, note: "캡차/보안 확인 페이지로 보임 (미검증)" };
  }
  if (/비정상적인\s*접근|일시적으로\s*제한/.test(bodyText)) {
    return { ok: false, blocked: true, blockType: "restricted", url, note: "다나와 접속 제한 페이지로 보임 (미검증)" };
  }

  const toInt = (v) => { const n = parseInt(String(v).replace(/[^\d]/g, ""), 10); return isNaN(n) ? null : n; };
  const mallNameOf = (logo) => {
    if (!logo) return "";
    const img = logo.querySelector("img[alt]");
    const span = logo.querySelector(".text__logo");
    return ((img && img.alt) || (span && span.textContent) || logo.textContent || "").trim();
  };

  // 1순위: 페이지 아래쪽 "가격비교" 목록(#priceCompareArea .diff_box). 위쪽 "쇼핑몰별 최저가"(몰당 1건, 상품명 없음)와 달리
  // 판매처가 올린 매물 전부(같은 몰의 여러 상품 포함)가 판매처가 붙인 상품명과 함께 나옴. 페이지가 뜬 뒤 따로 불러오는
  // 목록이지만 확장은 렌더링이 끝난 탭에서 읽으므로 그대로 보임(2026-09-22 사용자가 콘솔로 43건 전부 그려진 것 확인).
  //   <div class="diff_box">
  //     <div class="d_mall"><a><img alt="11번가"> 또는 <span class="txt_logo">프로젝터매니아</span></a></div>
  //     <div class="d_dsc"><div class="prc_line"><a><em class="prc_c">505,620</em>원</a></div>
  //                        <div class="info_line"><a href="...link_pcode=...">BS570 비비텍 4200안시 ...</a></div></div>
  //   </div>
  const items = [];
  document.querySelectorAll("#priceCompareArea .diff_box").forEach((box) => {
    const priceEl = box.querySelector(".prc_line .prc_c");
    const price = priceEl ? toInt(priceEl.textContent) : null;
    if (!price) return;
    const mallBox = box.querySelector(".d_mall");
    const img = mallBox ? mallBox.querySelector("img[alt]") : null;
    const logo = mallBox ? mallBox.querySelector(".txt_logo") : null;
    const mall = ((img && img.alt) || (logo && logo.textContent) || "").trim();
    if (!mall) return;
    const nameA = box.querySelector(".info_line a");
    const name = nameA ? nameA.textContent.trim() : "";
    const priceA = box.querySelector(".prc_line a");
    const link = (nameA && nameA.href) || (priceA && priceA.href) || url;
    items.push({ name, price, mall, link, kind: "danawa-detail", pid: null, pointTotal: null, nameFromSeller: !!name });
  });
  if (items.length) {
    return { ok: true, blocked: false, url, source: "DOM(상세)", count: items.length, items, note: "" };
  }

  // 2순위(폴백): 위쪽 "쇼핑몰별 최저가" 목록 — 몰당 1건, 상품명 없음
  const rows = document.querySelectorAll("ul.list__mall-price > li.list-item");
  if (!rows.length) {
    return { ok: false, blocked: false, url, source: "DOM(상세)", count: 0, items: [],
             note: "가격비교 목록(#priceCompareArea)과 '쇼핑몰별 최저가' 목록(ul.list__mall-price)을 둘 다 못 찾음 (페이지 구조가 바뀌었을 수 있음)" };
  }

  rows.forEach((li) => {
    const priceEl = li.querySelector(".box__price .text__num");
    const price = priceEl ? toInt(priceEl.textContent) : null;
    if (!price) return;
    const mall = mallNameOf(li.querySelector(".box__logo"));
    if (!mall) return;
    const a = li.querySelector("a.link__full-cover") || li.querySelector("a[href]");
    items.push({ name: "", price, mall, link: a ? a.href : url, kind: "danawa-detail", pid: null, pointTotal: null, nameFromSeller: false });
  });

  return { ok: items.length > 0, blocked: false, url, source: "DOM(상세)", count: items.length, items,
           note: items.length ? "가격비교 목록이 없어 '쇼핑몰별 최저가'(상품명 없음)로 대체" : "'쇼핑몰별 최저가' 목록은 찾았지만 개별 행을 못 뽑음 (페이지 구조 확인 필요)" };
})();
