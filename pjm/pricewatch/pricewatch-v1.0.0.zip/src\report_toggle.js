// 보고서의 "모델별 현황" 행 펼치기/접기 + 제목 옆 "전체 펼치기/접기" 버튼.
// 확장 안의 보고서 페이지(report.html)와, 다운로드 폴더에 같이 저장되는 독립 HTML 파일(보고서.html) 양쪽에서
// 이 파일 하나를 씀 — report.js 가 저장할 때 이 파일의 글자를 그대로 <script> 로 박아 넣음.
// 그래서 여기서는 chrome.* API 나 module import 를 쓰면 안 되고, 내용이 그려지기 전에 실행돼도 되도록
// document 에 이벤트 위임만 걸어둠.
(() => {
  const expandableRows = () => document.querySelectorAll("#content tr.expandable");
  const setAllRows = (open) => {
    expandableRows().forEach((row) => {
      const d = document.getElementById(row.dataset.toggle);
      if (!d) return;
      d.hidden = !open;
      row.classList.toggle("open", open);
    });
  };
  const updateToggleAllLabel = () => {
    const btn = document.getElementById("toggleAll");
    if (!btn) return;
    const rows = Array.from(expandableRows());
    const allOpen = rows.length > 0 && rows.every((row) => {
      const d = document.getElementById(row.dataset.toggle);
      return d && !d.hidden;
    });
    btn.textContent = allOpen ? "전체 접기" : "전체 펼치기";
  };

  document.addEventListener("click", (e) => {
    if (!e.target.closest("#content")) return;
    if (e.target.closest("a")) return; // 링크(네이버/다나와 등) 클릭은 그냥 링크만 열리게, 행 토글은 안 함
    const all = e.target.closest("#toggleAll");
    if (all) {
      setAllRows(all.textContent !== "전체 접기");
      updateToggleAllLabel();
      return;
    }
    const row = e.target.closest("tr[data-toggle]");
    if (!row) return;
    const detail = document.getElementById(row.dataset.toggle);
    if (!detail) return;
    detail.hidden = !detail.hidden;
    row.classList.toggle("open", !detail.hidden);
    updateToggleAllLabel();
  });
})();
