import { normalizeSheets } from "./lib/sheet.js";

const $ = (id) => document.getElementById(id);

// 첫 화면에 "조회할 시트: …"를 보여줌 — 실행 전에 어느 시트가 조회될지 확인할 수 있게(2026-11-01 매니아 요청 5번:
// 체크를 꺼도 두 시트가 다 조회된다고 함 — 저장 전 상태를 본 것으로 보임). 설정의 체크 상태를 그대로 읽어 적음.
let sheetLine = "";
const describeSheets = (s) => {
  const all = normalizeSheets(s), on = all.filter((x) => x.enabled);
  if (!all.length) return "설정에서 구글 시트를 먼저 추가하세요.";
  if (!on.length) return `등록된 시트 ${all.length}개가 모두 체크 해제되어 있습니다.`;
  return `조회할 시트: ${on.map((x) => x.name).join(", ")}${on.length < all.length ? ` (등록 ${all.length}개 중 ${on.length}개 체크)` : ""}`;
};

function render(status = {}) {
  const running = !!status.running;
  $("run").disabled = running;
  $("cancel").hidden = !running;
  const finished = status.phase === "완료" || status.phase === "중단됨";

  const sites = status.sites || {};
  const siteNames = Object.keys(sites);
  let text = "", pct = 0;

  if (status.error && !finished) {
    text = status.error;
  } else if (running && siteNames.length) {
    // 네이버/다나와가 각자 독립적으로 진행되니 사이트별로 한 줄씩 보여줌
    text = siteNames.map((name) => {
      const s = sites[name];
      if (s.error) return `${name}: ${s.error}`;
      return `${name}: ${s.phase || ""} ${s.done ?? 0}/${s.total ?? 0} ${s.current || ""}`.trim();
    }).join("\n");
    const pcts = siteNames.map((name) => (sites[name].total ? sites[name].done / sites[name].total : 0));
    pct = Math.round((pcts.reduce((a, b) => a + b, 0) / pcts.length) * 100);
  } else if (running) {
    text = `${status.phase || ""}\n${status.done}/${status.total} ${status.current || ""}`;
    pct = status.total ? Math.round((status.done / status.total) * 100) : 0;
  } else if (status.phase === "완료") {
    text = `완료 (${status.done}/${status.total}). 보고서 탭을 확인하세요.`;
    if (status.error) {
      // "한 사이트가 실패해도 나머지는 끝까지 진행" 설정으로 끝까지 돈 경우 — 완료는 됐지만 한쪽이 빠져 있음
      text += `\n⚠ ${status.error}`;
    } else if (status.incompleteSites && status.incompleteSites.length) {
      text += `\n⚠ ${status.incompleteSites.join(", ")}: 끝까지 못 갔습니다. 보고서에서 어디까지 됐는지 확인하세요.`;
    }
  } else if (status.phase === "중단됨") {
    // 네이버/다나와가 독립적으로 도니까, 합친 숫자(예: 45/45)만 보여주면 완료된 것처럼 헷갈릴 수 있음 —
    // 실제로 어느 조사가 어디까지 가다 끊겼는지 사이트별로 보여줌
    const perSite = siteNames.length
      ? siteNames.map((name) => `${name}: ${sites[name].phase || "중단됨"} (${sites[name].done ?? 0}/${sites[name].total ?? 0})`).join("\n")
      : `${status.done}/${status.total}까지 조회함`;
    text = status.error
      // 한 사이트 실패로 전체를 멈춘 경우 — 이유(탭 주소·오류 문구 포함)를 그대로 보여줌. 보고서 탭은 열림(CSV 없음).
      ? `중단됨\n${perSite}\n\n${status.error}`
      : `중단됨\n${perSite}\n이번 실행은 CSV/보고서를 만들지 않았습니다 (참고: "지난 보고서 열기"는 이전에 완료됐던 보고서입니다).`;
  } else {
    text = `버튼을 누르면 시트의 모델을 네이버 쇼핑/다나와에서 조회합니다.\n(네이버·다나와가 각자 탭에서 동시에 진행됩니다)${sheetLine ? `\n${sheetLine}` : ""}`;
  }

  $("prog").style.width = (running ? pct : finished ? 100 : 0) + "%";
  $("status").textContent = text;
  $("status").className = status.error ? "err" : "";
}

$("run").onclick = () => chrome.runtime.sendMessage({ type: "run" });
$("cancel").onclick = () => chrome.runtime.sendMessage({ type: "cancel" });
$("report").onclick = (e) => { e.preventDefault(); chrome.tabs.create({ url: chrome.runtime.getURL("src/report.html") }); };
$("opts").onclick = (e) => { e.preventDefault(); chrome.runtime.openOptionsPage(); };

chrome.runtime.onMessage.addListener((msg) => { if (msg.type === "status") render(msg.status); });
chrome.storage.sync.get({ sheets: [], sheetUrl: "" })
  .then((s) => { sheetLine = describeSheets(s); })
  .catch(() => {})
  .then(() => chrome.storage.local.get("status"))
  .then(({ status }) => render(status));
$("version").innerHTML = `<span class="company">Pixion Inc.</span> · v${chrome.runtime.getManifest().version}`;
