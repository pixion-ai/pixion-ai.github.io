// 실행 오케스트레이션 (서비스 워커)
// popup → "run" 메시지 → 시트 읽기 → 네이버/다나와를 각자 독립된 탭으로 동시에 끝까지 조회 → 결과 병합 →
// 보고서 저장/열기/CSV 다운로드

import { toCsvUrl, parseCsv, extractProducts, isLocalFileRef, toFileUrl, normalizeSheets, activeSheets } from "./lib/sheet.js";
import { filterItems, nameHasModel, isPointBelow, byRealPrice, catalogTargets, applyAppCoupon, DEFAULT_APP_COUPON, DEFAULT_EXCLUDE, DEFAULT_ACCESSORY_PRICE_RATIO, DEFAULT_NAVERPAY_BASE_RATE } from "./lib/match.js";
import { buildCsv, buildExcludedCsv, buildDetailCsv, summarize, formatStamp } from "./lib/report.js";
import { sellerTarget, parseSellerApi, resolveFromBridge, directSaleSeller, publicSeller, buildVendorCsv, applyMyVendors, SELLER_CACHE_TTL_MS } from "./lib/seller.js";

const DEFAULTS = {
  sheets: [], // [{name, url, enabled}] — 등록한 시트 중 체크된(enabled) 것 전부를 한 번 실행에 조회
  sheetUrl: "", // 예전 버전(시트 1개) 설정 — sheets 가 비어 있을 때만 normalizeSheets 가 대신 씀
  excludeWords: DEFAULT_EXCLUDE.join(", "),
  accessoryPriceRatio: DEFAULT_ACCESSORY_PRICE_RATIO, // 제외어(중고/리퍼 제외)가 매칭돼도, 가격이 기준가의 이 비율 이상이면 무시함. 옵션 화면엔 %로 표시(0~100), 저장은 0~1 비율로.
  naverPayBaseRate: DEFAULT_NAVERPAY_BASE_RATE, // 네이버페이 기본 적립률(%). 최대 적립에서 이만큼 뺀 나머지를 판매처 추가 포인트로 봄.
  naverAppCoupon: DEFAULT_APP_COUPON.enabled, // 네이버 앱 첫구매 쿠폰(최대 naverAppCouponMax 원, naverAppCouponRate %)을 스마트스토어 매물 판매가에서 뺄지 (match.js applyAppCoupon)
  naverAppCouponMax: DEFAULT_APP_COUPON.maxWon,
  naverAppCouponRate: DEFAULT_APP_COUPON.ratePct,
  catalogLookup: true, // 네이버 가격비교 묶음에 가려진 판매처를 카탈로그 페이지에서 한 번 더 확인 (naverExpandCatalog)
  continueOnSiteFailure: false, // 한 사이트(네이버/다나와)가 조회를 포기해도 나머지 사이트를 끝까지 돌릴지. 기본은 전체 중단.
  sellerLookup: true, // 기준가 미만 매물 중 오픈마켓 것은 상품 페이지를 열어 실제 판매자를 확인 (lookupSellers)
  myVendors: "", // 내 업체 이름(쉼표 구분) — 이 업체의 매물은 기준가 미만/포인트 반영 미만으로 세지 않음 (applyMyVendors)
  vendorGroups: "", // 같은 업체로 볼 이름들 — 한 줄에 "진주코리아=조은폰영상" (seller.js parseVendorGroups, groupViolations)
  tabMode: "reuseHidden", // "reuseHidden": 탭 재사용, 백그라운드 유지 (기본) / "reuseActive": 탭 재사용, 화면에 계속 표시
  delayMs: 1000, // 모델 간 대기 시간(ms). 0초는 버스트 제한에 걸려 금방 차단되고, 1~3초는 안정적으로 감 — 그 이하로 줄이면 다시 빨리 막힐 수 있음.
  maxRetries: 3, // "접속 제한"(restricted) 차단 시 자동 재시도 최대 횟수. 기본 3회 × retryWaitMs(4분) = 총 약 12분.
  retryWaitMs: 4 * 60 * 1000, // 재시도 간격(ms). 기본 4분.
};

let cancelRequested = false;

export async function getSettings() {
  const s = await chrome.storage.sync.get(DEFAULTS);
  return { ...DEFAULTS, ...s };
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const formatRemain = (ms) => {
  const totalSec = Math.max(0, Math.ceil(ms / 1000));
  const min = Math.floor(totalSec / 60), sec = totalSec % 60;
  return min > 0 ? `${min}분 ${sec}초` : `${sec}초`;
};

// 보고서를 CSV 3개(기준가 미만/제외어 확인/모델별 상세)로 나눠서 stamp 이름의 폴더 하나에 같이 내려받음.
// report.js 의 "CSV 다시 받기" 버튼도 report.createdAt 기준 같은 폴더명으로 동일한 3개를 내려받음.
async function downloadReportCsvs(stored, stamp) {
  // 저장된 보고서는 원본 그대로이고, 파일로 내보낼 때 "내 업체 이름" 설정을 적용함(내 업체 매물은 위반에서 뺌)
  const report = { ...stored, results: applyMyVendors(stored.results, stored.myVendors) };
  const folder = `pricewatch/${stamp}`;
  // 파일마다 따로 만들고 따로 저장 — 한 파일을 만들다 오류가 나도 나머지는 저장되게. 예전엔 넷을 한꺼번에 만들어서
  // 하나가 실패하면 넷 다 안 나왔고, 실패해도 console.warn 뿐이라 사용자는 폴더에 보고서.html 만 있는 걸 보고서야 알았음
  // (20260928_1502 실행). 실패한 파일 이름과 이유를 돌려줘 팝업에 알림.
  const files = [
    ["기준가미만.csv", () => buildCsv(report)],
    ["제외어확인.csv", () => buildExcludedCsv(report)],
    ["모델별상세.csv", () => buildDetailCsv(report)],
    ["업체별위반.csv", () => buildVendorCsv(report, { myVendors: report.myVendors, vendorGroups: report.vendorGroups })],
  ];
  const failed = [];
  for (const [name, build] of files) {
    try {
      await chrome.downloads.download({
        url: "data:text/csv;charset=utf-8," + encodeURIComponent("﻿" + build()),
        filename: `${folder}/${name}`, saveAs: false,
      });
    } catch (e) {
      console.warn("CSV 저장 실패", name, e);
      failed.push(`${name} (${(e && e.message) || e})`);
    }
  }
  return failed;
}

async function setStatus(patch) {
  const { status = {} } = await chrome.storage.local.get("status");
  const next = { ...status, ...patch, updatedAt: Date.now() };
  await chrome.storage.local.set({ status: next });
  chrome.runtime.sendMessage({ type: "status", status: next }).catch(() => {});
}

// 사이트 하나(네이버/다나와)의 진행 상황만 status.sites[사이트명] 에 병합해 넣음. 두 사이트가 동시에
// 독립적으로 도니까 이렇게 나눠야 서로 상태를 덮어쓰지 않음. 완벽한 동시성 보호는 아니지만 진행률
// 표시용이라 갱신 하나를 놓쳐도 다음 틱에서 바로 정정됨.
async function setSiteStatus(siteName, patch) {
  const { status = {} } = await chrome.storage.local.get("status");
  const sites = { ...(status.sites || {}) };
  sites[siteName] = { ...(sites[siteName] || {}), ...patch };
  const next = { ...status, sites, updatedAt: Date.now() };
  await chrome.storage.local.set({ status: next });
  chrome.runtime.sendMessage({ type: "status", status: next }).catch(() => {});
}

// 로딩 완료를 기다리되, 탭이 중간에 닫히면 바로 알아챔 — 안 그러면 이미 사라진 탭을 최대 25초간
// 크롬 API 호출 없이 기다리게 되는데, 이 유휴 시간이 길어지면 MV3 서비스워커가 통째로 종료될 수 있고
// 그러면 실행 중이던 run() 이 흔적도 없이 사라져서 "중단" 버튼을 눌러도 반응이 없는 것처럼 보임.
function waitForLoad(tabId, timeoutMs = 25000) {
  return new Promise((resolve) => {
    const cleanup = () => {
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(onUpdated);
      chrome.tabs.onRemoved.removeListener(onRemoved);
    };
    const timer = setTimeout(() => { cleanup(); resolve(false); }, timeoutMs);
    const onUpdated = (id, info) => {
      if (id === tabId && info.status === "complete") { cleanup(); resolve(true); }
    };
    const onRemoved = (id) => { if (id === tabId) { cleanup(); resolve(false); } };
    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.onRemoved.addListener(onRemoved);
  });
}

// sheetUrl 이 구글 시트면 fetch 로, 로컬 파일 경로면 탭을 열어서 읽음 (서비스워커의 fetch 는 file:// 접근이
// 막혀있을 가능성이 높아서 우회). 로컬 파일은 CSV여야 함(xlsx 파싱 미지원). "파일 URL에 대한 액세스 허용"이
// 꺼져 있거나 CSV가 다운로드로 처리되면 실패함.
async function readSheetCsv(sheetUrl) {
  if (!isLocalFileRef(sheetUrl)) {
    const resp = await fetch(toCsvUrl(sheetUrl), { credentials: "omit" });
    if (!resp.ok) throw new Error(`시트 응답 ${resp.status} — 공유 설정("링크가 있는 모든 사용자")을 확인하세요.`);
    return resp.text();
  }
  const fileUrl = toFileUrl(sheetUrl);
  const tab = await chrome.tabs.create({ url: fileUrl, active: false });
  try {
    await waitForLoad(tab.id);
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => document.body.innerText });
    const text = res && res.result;
    if (!text) throw new Error("파일 내용을 못 읽었습니다. chrome://extensions 에서 이 확장의 '파일 URL에 대한 액세스 허용'을 켰는지 확인하세요.");
    return text;
  } finally {
    try { await chrome.tabs.remove(tab.id); } catch (_) {}
  }
}

// sort: "price_asc"(낮은 가격순, 기본) | "rel"(네이버 기본 정렬 "랭킹순" — 아래 재검색 3단계에서만 씀)
export function searchUrl(brand, model, sort = "price_asc") {
  const q = encodeURIComponent(`${brand} ${model}`.trim()); // 시트 "제외어" 열의 단어는 검색어에 안 들어감(판단에만 씀)
  return `https://search.shopping.naver.com/search/all?query=${q}&sort=${sort}&pagingSize=${NAVER_PAGE_SIZE}`;
}

// ---- 네이버 재검색 (2026-11-03, 매니아 11.02 요청 3번) ----
// 낮은 가격순 1페이지는 "검색어에 걸린 전체 중 가장 싼 80개"라서, 그 안에 모델이 하나라도 있으면 더 싼 매물도 전부 있음.
// 놓치는 경우는 "80개가 꽉 찼는데 매칭 0" 하나뿐 — 네이버가 브랜드 단어만 맞는 매물도 같이 내놓는데 "프로젝터매니아"는 제조
// 브랜드이자 판매처 이름이라 자기 매물 수백 건에 들어가고, 모델마다 유통업체 수십 곳이 올려 500만 원 밑에만 80건이 넘음.
// 20261103_1739 실행: PM720LST(기준가 500만)의 1페이지가 1,590,000~4,465,880 전부 다른 PJM 프로젝터, PJM-Board 75(204만)는
// 9,710~359,100 전부 스탠드류. 매니아가 적은 PJM5000U 예시는 한 페이지 40개 링크였고 80개(프로그램 설정)로는 17건 잡힘.
// 그래서 그 조건일 때만 ① 브랜드 없이 낮은 가격순 → ② 브랜드+모델 랭킹순(네이버 기본 정렬)으로 다시 검색함. 다음 단계로 가는
// 조건도 같음 — 앞 단계 결과가 80개 미만이면 그 이름의 매물이 네이버에 없는 것이 확정이라(PJM500F) 더 안 봄. 랭킹순은 한 모델에
// 판매처가 80곳 넘으면 싼 곳이 2페이지로 밀려 최저가를 놓칠 수 있어 마지막 수단. 시트의 브랜드를 미리 비울 필요는 없음
// (브랜드가 도움이 되는 행 — "고캐스트 HDMI" 같은 코드 없는 이름 — 이 많고, 비워서 얻는 건 요청 1개 절약뿐). 재검색으로 찾으면
// 출처에 "(브랜드 없이 재검색)"이 붙고 보고서의 검색 링크도 그 주소로 바뀜. 못 찾으면 원래 결과를 두고 상태에 어디까지 해봤는지 적음.
const NAVER_PAGE_SIZE = 80;
// "꽉 찼다"의 기준 — __NEXT_DATA__ 의 상품 노드 수가 광고 포함/제외로 80에서 몇 개 어긋날 수 있어 90% 선. 한 페이지가 이보다
// 적으면 뒤 페이지가 없다는 뜻이라 재검색 안 함(Style 75C 처럼 결과 1개인 모델은 요청이 늘지 않음)
const NAVER_PAGE_FULL_MIN = Math.floor(NAVER_PAGE_SIZE * 0.9);
const naverPageFull = (data) => (data.productCount || 0) >= NAVER_PAGE_FULL_MIN;
const naverFallbackSearches = (brand, model) => [
  brand ? { label: "브랜드 없이", url: searchUrl("", model) } : null,
  { label: "랭킹순", url: searchUrl(brand, model, "rel") },
].filter(Boolean);

// 다나와 검색 URL. 정렬 파라미터(낮은가격순)는 JS로만 동작해서 URL로는 못 넘김 — 어차피 match.js 의
// filterItems 가 가격순으로 다시 정렬하므로 결과 정확도엔 지장 없음.
export function danawaSearchUrl(brand, model) {
  const q = encodeURIComponent(`${brand} ${model}`.trim());
  return `https://search.danawa.com/dsearch.php?query=${q}`;
}

// 조회할 사이트 목록. 하나 추가하려면 여기에 {name, buildUrl, file} 만 추가하면 됨.
// 각 사이트는 run() 안에서 자기만의 탭으로 처음부터 끝까지 독립적으로 진행됨 (아래 runSite 참고).
// expandDetail(옵션): 검색결과 페이지가 모델당 대표가 1건만 주는 사이트를 위한 2단계 확장 —
// 아래 danawaExpandDetail/DANAWA_DETAIL_FILE 참고.
const SITES = [
  // fallbackSearches/pageFull(옵션): 1페이지가 꽉 찼는데 매칭 0일 때 순서대로 다시 검색(위 "네이버 재검색" 참고). 다나와엔 없음.
  { name: "네이버", buildUrl: searchUrl, file: "src/extractor.js", expandDetail: naverExpandCatalog, fallbackSearches: naverFallbackSearches, pageFull: naverPageFull },
  { name: "다나와", buildUrl: danawaSearchUrl, file: "src/extractor_danawa.js", expandDetail: danawaExpandDetail },
];

// 탭 1개를 계속 재사용하며 URL만 바꿔가며 조회. tabState.id 가 있으면 그 탭을 재사용하고,
// 없으면 새로 만듦(최초 1회, 또는 이전 탭이 캡차/오류로 빠진 뒤). 캡차는 사용자가 직접 풀어야 하니
// 탭을 활성화해서 남겨둠. 접속 제한(restricted)은 사용자가 할 게 없고 자동으로 재시도할 것이므로
// 탭을 조용히 정리함 (매번 화면을 가로채면 방해만 됨).
async function extractFromTab(url, tabState, mode, file) {
  const active = mode === "reuseActive";
  let tabId = tabState.id;
  try {
    if (tabId != null) await chrome.tabs.update(tabId, { url });
    else {
      const tab = await chrome.tabs.create({ url, active });
      tabId = tab.id;
      tabState.id = tabId;
    }
    await waitForLoad(tabId);
    await sleep(1500); // 클라이언트 렌더링 대기
    const [res] = await chrome.scripting.executeScript({ target: { tabId }, files: [file] });
    const data = res && res.result ? res.result : { ok: false, items: [], note: "추출기 응답 없음" };
    if (data.blocked) {
      tabState.id = null;
      if (data.blockType === "captcha") {
        await chrome.tabs.update(tabId, { active: true });
        data.tabId = tabId; // 캡차 탭은 남겨두므로 호출한 쪽(lookupSellers)이 사람이 푼 뒤 같은 탭을 다시 읽을 수 있게 번호를 실어 보냄
      } else { try { await chrome.tabs.remove(tabId); } catch (_) {} }
      return data;
    }
    return data;
  } catch (e) {
    // tabs.update/executeScript 가 실패한 경우. 두 가지를 구분함:
    //  (1) 탭은 살아 있는데 요청한 사이트가 아닌 다른 주소에 가 있음 — 사이트가 제한/보안 페이지 등 자기 도메인
    //      밖으로 보낸 것. 그 주소는 host_permissions 에 없어 읽을 수 없으니 겉으로는 탭 오류지만 실제로는
    //      접속 제한이므로 "restricted" 로 취급해 대기 후 재시도함(2026-09-22 고객사에서 첫 모델부터 이 경로로
    //      3번 즉시 실패해 네이버 전체가 조용히 빠진 사례).
    //  (2) 탭이 정말 사라졌거나(실수로 닫음) 같은 주소인데도 실패 — "tabError" 로 대기 없이 즉시 재시도.
    // 어느 쪽이든 그때 탭 주소와 오류 내용을 note 에 남겨 보고서/팝업에서 원인을 볼 수 있게 함.
    tabState.id = null;
    let tabUrl = "";
    try { if (tabId != null) tabUrl = (await chrome.tabs.get(tabId)).url || ""; } catch (_) { /* 탭이 사라짐 */ }
    const wantHost = hostOf(url), gotHost = hostOf(tabUrl);
    if (tabUrl && gotHost && gotHost !== wantHost) {
      // 로그인 페이지로 보낸 경우는 기다려도 풀리지 않음 — 사람이 로그인해야 함. 접속 제한처럼 4분씩 재시도하면 시간만 버림
      // (2026-09-28 실제 사례: 네이버가 첫 모델부터 nid.naver.com 으로 보냈는데 "접속 제한"으로 보고 4분 × 3번을 기다린 뒤에야
      // 멈춤). 그래서 바로 멈추고, 그 탭을 화면에 띄워 남겨 사용자가 로그인할 수 있게 함(캡차와 같은 처리).
      if (isLoginUrl(tabUrl)) {
        try { await chrome.tabs.update(tabId, { active: true }); } catch (_) {}
        return { ok: false, blocked: true, blockType: "login", url: tabUrl, items: [],
                 note: `보안 확인·로그인 페이지(${gotHost})로 이동됨` };
      }
      try { await chrome.tabs.remove(tabId); } catch (_) {}
      return { ok: false, blocked: true, blockType: "restricted", url: tabUrl, items: [],
               note: `${wantHost} 대신 다른 주소(${gotHost})로 이동됨 — 접속 제한으로 간주` };
    }
    return { ok: false, blocked: true, blockType: "tabError", url: tabUrl, items: [],
             note: `탭 오류(자동 재시도): ${e && e.message}${tabUrl ? ` [탭 주소: ${tabUrl}]` : " [탭이 닫힘]"}` };
  }
}

const hostOf = (u) => { try { return new URL(u).host; } catch (_) { return ""; } };
// 로그인 페이지 주소인지 — 네이버는 nid.naver.com, 그 밖에는 주소에 login/signin 이 들어간 경우
const isLoginUrl = (u) => {
  try {
    const x = new URL(u);
    return /^nid\.naver\.com$/.test(x.host) || /(^|\.)(login|accounts|auth|member)\./.test(x.host) || /log-?in|sign-?in/i.test(x.pathname);
  } catch (_) { return false; }
};

const TAB_ERROR_MAX_RETRIES = 3; // 탭이 닫히는 등 blockType:"tabError" 일 때, 대기 없이 즉시 새 탭으로 재시도할 최대 횟수

// 네이버 검색결과의 가격비교 묶음(lowMallList)은 싼 순으로 5곳만 줘서, 그 뒤로 잘린 판매처는 안 보임.
// 카탈로그 페이지를 한 번 더 열면 판매처별 목록을 10곳까지, 실제 링크·상품번호·일부 포인트까지 받을 수 있음.
// 다만 모델마다 네이버 요청이 하나씩 늘어 접속 제한(약 15개마다 4분 대기)이 더 자주 걸리므로 **필요한 모델에만** 엶:
// 묶음이 5곳으로 꽉 차 있고(=뒤가 잘렸고), 그중 가장 비싼 가격이 기준가×CATALOG_PRICE_MARGIN 보다 쌀 때만.
// 묶음은 싼 순이라 잘린 판매처는 5번째보다 비싸므로, 5번째가 이 선보다 비싸면 잘린 쪽은 기준가 미만일 수 없음.
// 여유분(5%)은 포인트 반영 시 기준가 미만이 될 수 있는 판매처(적립은 보통 1~2%)까지 보려고 둔 것.
const NAVER_CATALOG_FILE = "src/extractor_naver_catalog.js";
const NAVER_CATALOG_MAX_ITEMS = 1; // 한 모델에서 카탈로그를 여는 최대 개수(요청 수 억제)

async function naverExpandCatalog(data, tabState, tabMode, model, opts = {}) {
  if (opts.catalogLookup === false || !opts.basePrice) return data;
  const items = data.items || [];
  // 어떤 묶음을 열어볼지는 순수 함수(match.js catalogTargets)가 판정 — test/run.mjs 로 검증 가능하게 분리해둠
  const targets = catalogTargets(items, model, opts.basePrice, { max: NAVER_CATALOG_MAX_ITEMS, exclude: opts.exclude });
  if (!targets.length) return data;

  let out = items;
  const notes = [];
  let expanded = 0;
  for (const catalogId of targets) {
    const res = await extractFromTab(`https://search.shopping.naver.com/catalog/${catalogId}`, tabState, tabMode, NAVER_CATALOG_FILE);
    if (res.blocked) return res; // 이 모델 전체를 차단으로 취급 -> 기존 재시도 로직에 맡김
    if (res.ok && res.items && res.items.length) {
      // 묶음 대표명을 카탈로그 페이지 항목에도 붙여 둠 — 교체하면서 검색결과의 묶음 항목(대표명을 가진)이 사라지므로
      const rep = out.find((it) => it.catalogId === catalogId && (it.catalogName || it.name));
      const catalogName = rep ? (rep.catalogName || rep.name) : "";
      // 같은 카탈로그의 묶음 항목은 카탈로그 페이지에서 받은 더 정확한 목록으로 교체
      out = out.filter((it) => it.catalogId !== catalogId || (it.kind !== "lowMall" && it.mall !== "가격비교(카탈로그)"));
      out = out.concat(res.items.map((it) => ({ ...it, name: it.name || model, catalogName })));
      expanded++;
    }
    if (res.note) notes.push(res.note);
  }
  // 출처에 2단계를 거쳤는지 남김 — 보고서 "모델별 상세"에서 카탈로그까지 봤는지 바로 알 수 있게
  return { ...data, items: out, source: expanded ? `${data.source || "-"}+카탈로그` : data.source,
           note: [data.note, ...notes].filter(Boolean).join(" / ") };
}

// 다나와 검색결과 페이지는 모델당 "대표가" 1건만 주는데, 그 대표 항목의 링크(=상세/가격비교 페이지)를
// 한 번 더 열어서 실제 판매처별 가격(extractor_danawa_detail.js)을 뽑아옴. 검색결과에 모델명 외 다른
// 상품이 섞여 있을 수 있어(광고 등) DANAWA_DETAIL_MAX_ITEMS 개까지만 확장하고 나머지는 원래 대표가
// 항목 그대로 둠.
const DANAWA_DETAIL_FILE = "src/extractor_danawa_detail.js";
const DANAWA_DETAIL_MAX_ITEMS = 2;

async function danawaExpandDetail(data, tabState, tabMode, model, opts = {}) {
  const items = data.items || [];
  if (!items.length) return data; // 검색결과 자체가 없으면 더 볼 것도 없음
  // 상품명에 모델명이 아예 없는 검색결과는 filterItems 단계에서 "모델명 불일치"로 버려질 게 뻔하니,
  // 상세페이지까지 열어보는 건 낭비 — 미리 걸러서 DANAWA_DETAIL_MAX_ITEMS 예산을 진짜 후보에만 씀.
  const candidates = items.filter((it) => nameHasModel(it.name, model, opts.exclude));
  const skipped = items.filter((it) => !nameHasModel(it.name, model, opts.exclude)); // 이대로 두면 filterItems 가 알아서 걸러줌
  const toExpand = candidates.slice(0, DANAWA_DETAIL_MAX_ITEMS);
  const rest = [...candidates.slice(DANAWA_DETAIL_MAX_ITEMS), ...skipped];
  const expanded = [];
  const notes = [];
  for (const it of toExpand) {
    if (!it.link || !/^https?:\/\/prod\.danawa\.com\//.test(it.link)) { expanded.push(it); continue; }
    const detail = await extractFromTab(it.link, tabState, tabMode, DANAWA_DETAIL_FILE);
    if (detail.blocked) return detail; // 상세페이지에서 차단되면 이 모델 전체를 차단으로 취급 -> 기존 재시도 로직에 맡김
    if (detail.ok && detail.items && detail.items.length) {
      // 상세페이지 행에 상품명이 없으면(name:"") 검색결과의 대표 상품명으로 대체 — 네이버 lowMallList 와 동일한 폴백
      // 상세페이지 행에 상품명이 없으면 검색결과 대표명을 빌려 씀 — 그 경우 판매처가 붙인 이름이 아니므로 nameFromSeller 는 false
      // 검색결과 항목(=다나와 상품 하나)을 묶음으로 보고 대표명을 붙임 — 판매처 상품명에 모델명이 없어도 묶음 기준으로 판정(modelMatcher)
      expanded.push(...detail.items.map((d) => ({ ...(d.name ? d : { ...d, name: it.name, nameFromSeller: false }), catalogId: `danawa:${it.link}`, catalogName: it.name })));
    } else {
      expanded.push(it); // 상세페이지 파싱 실패 시 원래 대표가 1건이라도 남겨서 데이터 유실 방지
      if (detail.note) notes.push(detail.note);
    }
  }
  // 출처에 상세페이지까지 봤는지 남김(예: "DOM+상세") — 안 그러면 2단계가 실패해도 화면상 구분이 안 됨
  const detailCount = expanded.filter((it) => it.kind === "danawa-detail").length;
  return { ...data, items: [...expanded, ...rest], source: detailCount ? `${data.source || "-"}+상세` : data.source,
           note: [data.note, ...notes].filter(Boolean).join(" / ") };
}

const REJECTED_KEEP = 80; // 보고서에 남기는 모델당 제외 상품 수(검색결과 한 페이지가 80개)

let runInFlight = false; // 이전 run() 이 아직 뒷정리 중일 때(취소 직후 등) 새 run() 이 겹쳐 돌지 않게 막음


// 공개 데이터(JSON) 주소를 바로 읽어 판매자 정보를 꺼냄 — 추출기와 같은 모양({ok, blocked, seller, note})으로 돌려줌.
// 접속 거부(403/429)는 차단으로 봐서 그 장터를 이번 실행에서 그만두게 함.
async function fetchSellerApi(target) {
  try {
    const res = await fetch(target.api, { headers: { Accept: "application/json" } });
    if (res.status === 403 || res.status === 429) {
      return { ok: false, blocked: true, blockType: "restricted", seller: null, note: `${target.market}이 접속을 막음 (HTTP ${res.status})` };
    }
    if (!res.ok) return { ok: false, blocked: false, seller: null, note: `HTTP ${res.status}` };
    const seller = parseSellerApi(target.market, await res.json());
    return seller
      ? { ok: true, blocked: false, seller, note: "" }
      : { ok: false, blocked: false, seller: null, note: "판매자 정보를 찾지 못함 (판매 종료된 상품이거나 데이터 구조가 바뀜)" };
  } catch (e) {
    return { ok: false, blocked: false, seller: null, note: `읽기 실패: ${e && e.message}` };
  }
}

// 오픈마켓이 봇 확인·접속 제한 화면을 띄우면 이번 실행에서는 그 마켓을 더 열지 않음 — 접속 제한처럼 몇 분씩
// 기다리지 않음(판매자 확인은 부가 정보라 가격 조회 시간을 늘릴 만큼 중요하진 않음).
// 판매자 표시를 못 찾은 것(판매 종료, 처음 보는 페이지 모양)은 막힌 게 아니므로 남은 매물을 끝까지 열어봄.
// 2026-09-28 이전엔 이런 실패도 3번 연속이면 그 마켓을 그만뒀는데, 20260928_1502 실행에서 쿠팡 3건(덜 그려진 페이지,
// 반품 페이지, 쿠팡 직접 판매 페이지)이 연달아 실패해 뒤의 7건을 열어보지도 않고 "미확인"으로 남겼음 — 사용자 요청으로 변경.
const SELLER_REREAD_MAX = 2;          // 못 읽었을 때 같은 탭을 다시 읽는 횟수
const SELLER_REREAD_WAIT_MS = 2000;   // 다시 읽기 전 대기
// 장터가 봇 확인(캡차)을 띄우면 그 탭을 화면에 띄워 두고 이만큼 기다리며 사람이 풀었는지 확인함(2026-11-03).
// 20261103_1739·2158 실행에서 G마켓이 Cloudflare "사람인지 확인하십시오" 화면을 띄웠는데, 예전엔 그 장터를 이번 실행에서
// 바로 그만둬서 체크를 눌러도 다음 실행에서야 반영됐음("걸리면 무시하고 끝내버린다"). 지금은 SELLER_CAPTCHA_POLL_MS 마다
// 그 탭에 추출기를 다시 넣어 보고, 풀렸으면 같은 실행에서 그 장터의 남은 매물을 이어서 조회함. 시간 안에 안 풀리면 예전처럼 그만둠.
const SELLER_CAPTCHA_WAIT_MS = 2 * 60 * 1000;
const SELLER_CAPTCHA_POLL_MS = 5000;

/**
 * 기준가 미만(포인트 반영 포함) 매물 중 오픈마켓 것의 실제 판매자를 상품 페이지에서 읽어 item.seller 에 붙임.
 * 2026-09-27 추가 — 고객사가 위반 업체에 직접 연락하려면 "11번가" 같은 장터 이름이 아니라 입점 업체를 알아야 해서.
 * - 같은 상품(마켓|상품번호)은 한 번만 열고, 결과는 storage.local.sellerCache 에 한 달 저장 → 하루 2회 실행이면
 *   두 번째부터는 새로 나타난 매물만 엶.
 * - below/pointBelow 의 원소는 matched 의 원소와 같은 객체라 여기서 붙이면 모델별 상세에도 같이 나옴.
 * - 사용자가 중단을 누르면 남은 조회만 건너뜀(가격 조회는 이미 끝났으므로 보고서는 그대로 만듦).
 * 반환: { total, done, cached, failed, cancelled, skippedMarkets, notes } — report.sellerLookup
 */
async function lookupSellers(results, settings) {
  const stat = { total: 0, done: 0, cached: 0, failed: 0, cancelled: false, skippedMarkets: [], notes: [] };
  const byKey = new Map();
  for (const r of results) {
    for (const it of [...r.below, ...(r.pointBelow || [])]) {
      const t = sellerTarget(it);
      if (!t) continue;
      if (!byKey.has(t.key)) byKey.set(t.key, { ...t, items: [] });
      byKey.get(t.key).items.push(it);
    }
  }
  stat.total = byKey.size;
  if (!stat.total) return stat;

  const { sellerCache = {} } = await chrome.storage.local.get("sellerCache");
  const now = Date.now();
  for (const k of Object.keys(sellerCache)) if (now - sellerCache[k].at >= SELLER_CACHE_TTL_MS) delete sellerCache[k];
  // 예전 버전이 저장해 둔 정보에는 대표자·연락처가 들어 있음 — 이번에 쓰는 것뿐 아니라 저장분 전체에서 빼 둠
  for (const k of Object.keys(sellerCache)) sellerCache[k].seller = publicSeller(sellerCache[k].seller);
  const tabState = { id: null };
  const blockedMarkets = new Set();
  let n = 0;
  for (const t of byKey.values()) {
    n++;
    let seller = sellerCache[t.key] ? sellerCache[t.key].seller : null;
    if (seller) stat.cached++;
    else if (cancelRequested) stat.cancelled = true;
    else if (!blockedMarkets.has(t.market)) {
      await setSiteStatus("판매자 확인", { phase: "조회 중", done: n - 1, total: stat.total, current: t.market, error: null });
      // 장터에 따라 상품 페이지를 탭으로 열어 읽거나(file), 페이지가 쓰는 공개 데이터를 바로 읽음(api — 롯데ON)
      // 주소를 아직 모르는 매물(쿠팡의 옵션 번호만 있는 다나와 매물)은 다나와 리디렉션 페이지의 글자에서 도착지를 읽음
      if (t.bridge && !t.url) {
        try { t.url = resolveFromBridge(t.market, await (await fetch(t.bridge)).text()); } catch (_) { t.url = ""; }
      }
      let data = t.api ? await fetchSellerApi(t)
        : t.url ? await extractFromTab(t.url, tabState, settings.tabMode, t.file)
          : { ok: false, blocked: false, seller: null, note: "상품 페이지 주소를 알아내지 못함" };
      // 봇 확인 화면이면 사람이 풀 때까지 기다렸다가 같은 탭을 다시 읽음(위 SELLER_CAPTCHA_WAIT_MS 설명 참고).
      // 풀리면 그 탭을 계속 재사용함(확인을 통과한 탭이라 다음 매물도 그대로 열림).
      if (data && data.blocked && data.tabId != null && t.file) {
        const tabId = data.tabId;
        const until = Date.now() + SELLER_CAPTCHA_WAIT_MS;
        while (Date.now() < until && !cancelRequested) {
          await setSiteStatus("판매자 확인", { phase: `${t.market} 봇 확인 — 열린 탭에서 확인을 마치면 이어서 조회합니다 (${formatRemain(until - Date.now())} 안에)`, done: n - 1, total: stat.total, current: t.market });
          await sleep(SELLER_CAPTCHA_POLL_MS);
          let res = null;
          try { [res] = await chrome.scripting.executeScript({ target: { tabId }, files: [t.file] }); } catch (_) { break; } // 탭이 닫혔거나 다른 주소로 감
          const again = res && res.result;
          if (!again || again.blocked) continue; // 아직 확인 화면
          data = again;
          tabState.id = tabId;
          break;
        }
        if (data && data.blocked) data.note = `${data.note || "봇 확인을 요구함"} — ${Math.round(SELLER_CAPTCHA_WAIT_MS / 60000)}분 안에 풀리지 않아 이 장터는 그만둠`;
      }
      // 못 읽었으면 같은 탭을 잠시 뒤 다시 읽음(페이지를 새로 열지 않음) — 판매자 표시가 늦게 그려지는 경우가 있는 것으로 보임.
      // 20260928_1502 실행에서 쿠팡 BH563LST(이제이테크) 매물을 못 읽었는데, 같은 페이지를 사용자가 열어 같은 코드를
      // 콘솔에서 돌리니 바로 읽혔음.
      for (let i = 0; i < SELLER_REREAD_MAX && t.file && data && !data.ok && !data.blocked && tabState.id != null; i++) {
        await sleep(SELLER_REREAD_WAIT_MS);
        try {
          const [res] = await chrome.scripting.executeScript({ target: { tabId: tabState.id }, files: [t.file] });
          if (res && res.result) data = res.result;
        } catch (_) { break; }
      }
      if (data && data.ok && data.seller) {
        seller = publicSeller(data.seller); // 대표자 이름·연락처 등 개인 정보는 남기지 않음
        sellerCache[t.key] = { seller, at: now };
      } else {
        stat.failed++;
        // 봇 확인·접속 제한이면 그 장터는 이번 실행에서 바로 그만둠(같은 화면을 여러 번 띄워봐야 소용없고 의심만 삼).
        // 그 밖의 실패(판매 종료된 상품 등)는 그 매물만 미확인으로 두고 다음 매물로 넘어감.
        if (stat.notes.length < 5) stat.notes.push(`${t.market}: ${(data && data.note) || "응답 없음"}`);
        if (data && data.blocked) { blockedMarkets.add(t.market); stat.skippedMarkets.push(t.market); }
      }
      await sleep(Number(settings.delayMs) || 0);
    }
    if (seller) {
      stat.done++;
      // 장터가 직접 파는 매물은 이름을 "쿠팡직판"처럼 바꿔 붙임 — "쿠팡"만 나오면 판매자 미확인과 헷갈림
      for (const it of t.items) it.seller = { ...directSaleSeller(seller, t.market), market: t.market, url: t.url };
    }
  }
  if (tabState.id != null) { try { await chrome.tabs.remove(tabState.id); } catch (_) {} }
  await chrome.storage.local.set({ sellerCache });
  await setSiteStatus("판매자 확인", { phase: stat.cancelled ? "중단됨" : "완료", done: stat.done, total: stat.total, current: "" });
  return stat;
}

async function run() {
  if (runInFlight) {
    // 취소 직후엔 팝업이 바로 "중단됨"으로 바뀌어 버튼이 눌리지만, 뒤에서는 예전 실행이 탭 정리 등으로
    // 몇 초 더 살아있을 수 있음 — 그 사이 또 누르면 여기서 조용히 무시하지 않고 이유를 알려줌.
    await setStatus({ error: "이전 실행이 아직 정리 중입니다. 몇 초 후 다시 눌러주세요." });
    return;
  }
  runInFlight = true;
  try {
    await runOnce();
  } finally {
    runInFlight = false;
  }
}

async function runOnce() {
  cancelRequested = false;
  const settings = await getSettings();
  // 설정에 등록된 시트 중 체크된 것만 조회 — 주소를 지우지 않고도 잠시 빼둘 수 있게(2026-09-27)
  const sheets = activeSheets(settings);
  if (!sheets.length) {
    const registered = normalizeSheets(settings).length;
    await setStatus({ running: false, error: registered
      ? `등록된 시트 ${registered}개가 모두 체크 해제되어 있습니다. 설정에서 조회할 시트를 체크하세요.`
      : "설정에서 구글 시트를 먼저 추가하세요." });
    return;
  }
  const excludeWords = settings.excludeWords.split(/[,\n]/).map((s) => s.trim()).filter(Boolean);
  const accessoryPriceRatioNum = Number(settings.accessoryPriceRatio);
  const accessoryPriceRatio = Number.isFinite(accessoryPriceRatioNum) ? accessoryPriceRatioNum : DEFAULT_ACCESSORY_PRICE_RATIO; // 0(%)도 유효한 설정값이라 || 로 처리하면 안 됨
  const naverPayBaseRateNum = Number(settings.naverPayBaseRate);
  const naverPayBaseRate = Number.isFinite(naverPayBaseRateNum) ? naverPayBaseRateNum : DEFAULT_NAVERPAY_BASE_RATE;
  const catalogLookup = settings.catalogLookup !== false;
  // 네이버 앱 첫구매 쿠폰 반영(기본 끔). 금액·비율이 숫자가 아니면 기본값(3,000원, 10%)
  const appCoupon = {
    enabled: settings.naverAppCoupon === true,
    maxWon: Number.isFinite(Number(settings.naverAppCouponMax)) ? Number(settings.naverAppCouponMax) : DEFAULT_APP_COUPON.maxWon,
    ratePct: Number.isFinite(Number(settings.naverAppCouponRate)) ? Number(settings.naverAppCouponRate) : DEFAULT_APP_COUPON.ratePct,
  };

  // 등록한 시트를 전부 읽어서 모델을 한 목록으로 합침. 각 모델/건너뛴 행에 어느 시트에서 왔는지(sheet) 붙여둠.
  // 시트 하나라도 못 읽으면 보고서가 불완전해지니 실행 전체를 멈춤.
  const products = [], skipped = [];
  for (const [si, sheet] of sheets.entries()) {
    await setStatus({ running: true, error: null, phase: "시트 읽는 중", sites: {}, done: si, total: sheets.length, current: sheet.name });
    try {
      const csvText = await readSheetCsv(sheet.url);
      const r = extractProducts(parseCsv(csvText));
      products.push(...r.products.map((p) => ({ ...p, sheet: sheet.name })));
      skipped.push(...r.skipped.map((k) => ({ ...k, sheet: sheet.name })));
    } catch (e) {
      // 구글 시트가 "링크가 있는 모든 사용자"로 공유돼 있지 않으면 export 주소가 로그인 페이지로 리디렉션되고,
      // 그 페이지는 CORS 헤더가 없어 fetch 가 "Failed to fetch" 로만 실패함 — 원인이 안 보이니 공유 설정 안내를 덧붙임
      // (2026-09-22, 새로 만든 시트를 공유 안 한 채 실행해서 발견).
      const hint = /Failed to fetch/i.test(e.message) && !isLocalFileRef(sheet.url)
        ? " — 시트가 공유 → '링크가 있는 모든 사용자(뷰어)'로 열려 있는지 확인하세요. (chrome://extensions 의 '오류'에 로그인 페이지로 리디렉션된 기록이 남을 수 있는데, 공유 설정 후엔 무시해도 됩니다)"
        : "";
      await setStatus({ running: false, error: `시트 "${sheet.name}" 읽기 실패: ${e.message}${hint}` });
      return;
    }
  }
  if (!products.length) { await setStatus({ running: false, error: "시트에서 기준가가 있는 모델을 찾지 못했습니다." }); return; }

  const startedAt = Date.now();
  const maxRetries = Number(settings.maxRetries) || 0;
  const delayMs = Number(settings.delayMs) || 0;
  const retryWaitMs = Number(settings.retryWaitMs) || 0;
  const retryWaitMin = Math.round(retryWaitMs / 60000);
  const continueOnSiteFailure = settings.continueOnSiteFailure === true;
  // 한 사이트가 조회를 포기하면 여기에 기록됨. 기본 설정에서는 다른 사이트도 이걸 보고 곧바로 멈춤 —
  // 한쪽(예: 네이버) 결과가 통째로 빠진 반쪽 보고서를 끝까지 만드는 건 의미가 없고, 오히려 정상 보고서로
  // 오해하기 쉬워서(2026-09-22 고객사 사례). 설정 continueOnSiteFailure 를 켜면 예전처럼 나머지를 끝까지 돌림.
  let siteAbort = null; // { site, msg }

  // 사이트 하나를 처음부터 끝까지 자기만의 탭으로 독립적으로 훑음. 네이버가 차단으로 멈춰 기다리는 동안에도
  // 다나와는 영향받지 않고 자기 페이스대로 계속 진행됨 (반대도 마찬가지).
  async function runSite(site) {
    const tabState = { id: null };
    const itemsByIndex = new Array(products.length).fill(null); // i번째 모델 결과, 아직 도달 못했으면 null
    let stopReason = null; // null(끝까지 다 돎) | "cancelled" | "blocked" | "aborted"(다른 사이트 실패로 중단)
    let siteBlockCount = 0; // 이 사이트에서 "차단" 응답을 받은 횟수(재시도로 넘어간 것 포함)
    let siteError = ""; // 이 사이트가 포기한 이유(보고서 경고 띠·팝업에 표시)
    const giveUp = async (msg) => {
      stopReason = "blocked";
      siteError = msg;
      await setSiteStatus(site.name, { phase: "차단됨", error: msg });
      if (!continueOnSiteFailure && !siteAbort) siteAbort = { site: site.name, msg };
    };
    const firstIndexByModel = new Map(); // 여러 시트에 같은 모델이 있으면 검색은 한 번만 하고 결과를 재사용
    // 이 검색결과에 이 모델로 인정되는 매물이 하나라도 있는지 — run() 의 최종 판정(filterItems)과 같은 기준
    const hasMatch = (d, p) => filterItems(d.items || [], p.model, { excludeWords, modelExclude: p.exclude, basePrice: p.basePrice, accessoryPriceRatio, naverPayBaseRate }).matched.length > 0;
    // 1페이지가 꽉 찼는데 매칭 0 → site.fallbackSearches 순서대로 재검색(위 "네이버 재검색" 주석). 차단이 나면 그걸 그대로 돌려
    // 기존 재시도 흐름에 맡김. 찾으면 그 결과(출처·검색 주소 바꿈), 끝까지 못 찾으면 원래 결과 + 해본 단계(retried)를 돌려줌.
    const searchFallbacks = async (data, p, brand, i) => {
      if (!site.fallbackSearches || hasMatch(data, p) || !site.pageFull(data)) return data;
      const tried = [];
      for (const fb of site.fallbackSearches(brand, p.model)) {
        if (cancelRequested || siteAbort) break;
        await sleep(delayMs);
        await setSiteStatus(site.name, { phase: `재검색 중 (${fb.label})`, done: i, total: products.length, current: p.model });
        const res = await extractFromTab(fb.url, tabState, settings.tabMode, site.file);
        if (res.blocked) return res;
        tried.push(fb.label);
        if (hasMatch(res, p)) return { ...res, source: `${res.source || "-"}(${fb.label} 재검색)`, retried: tried, searchUrl: fb.url };
        if (!site.pageFull(res)) break; // 이 검색어로도 1페이지가 안 찼으면 그 이름의 매물이 없는 것 — 다음 단계 안 봄
      }
      return { ...data, retried: tried };
    };
    for (let i = 0; i < products.length && stopReason == null; i++) {
      if (cancelRequested) { stopReason = "cancelled"; break; }
      if (siteAbort) { stopReason = "aborted"; break; }
      const p = products[i];
      const brand = p.brand || ""; // 시트의 브랜드 열(또는 모델명 칸 앞의 한글) — 설정에는 브랜드가 더 이상 없음
      const searchKey = `${brand}|${p.model}|${(p.exclude || []).join(",")}`; // 제외어가 다르면 2단계 후보가 달라져 따로 조회
      const prev = firstIndexByModel.get(searchKey);
      if (prev != null && itemsByIndex[prev]) { itemsByIndex[i] = itemsByIndex[prev]; continue; }
      firstIndexByModel.set(searchKey, i);
      const url = site.buildUrl(brand, p.model);

      let data, retries = 0, tabErrorRetries = 0;
      while (true) {
        await setSiteStatus(site.name, { phase: "조회 중", done: i, total: products.length, current: p.model, error: null });
        data = await extractFromTab(url, tabState, settings.tabMode, site.file);
        if (!data.blocked && !cancelRequested) data = await searchFallbacks(data, p, brand, i);
        if (!data.blocked && site.expandDetail && !cancelRequested) {
          await setSiteStatus(site.name, { phase: "개별 판매처 확인 중", done: i, total: products.length, current: p.model });
          data = await site.expandDetail(data, tabState, settings.tabMode, p.model, { basePrice: p.basePrice, catalogLookup, exclude: p.exclude });
        }
        if (!data.blocked) break;

        // 탭이 실수로 닫히는 등의 문제(blockType: "tabError")는 접속 제한이 아니므로 대기 없이 새 탭으로
        // 바로 재시도함 — 계속 실패하면 그때 진짜 문제로 보고 멈춤. 진짜 "차단"이 아니라서 siteBlockCount
        // (보고서의 차단 횟수 카드)에는 안 셈.
        if (data.blockType === "tabError") {
          if (cancelRequested) { stopReason = "cancelled"; break; }
          if (siteAbort) { stopReason = "aborted"; break; }
          tabErrorRetries++;
          if (tabErrorRetries > TAB_ERROR_MAX_RETRIES) {
            await giveUp(`${site.name} 탭에 계속 문제가 생겨(${p.model}) ${TAB_ERROR_MAX_RETRIES}번 다시 열어봤지만 안 됐습니다. 마지막 오류: ${data.note || "-"}`);
            break;
          }
          await setSiteStatus(site.name, { phase: `탭 문제로 재시도 중 (${tabErrorRetries}/${TAB_ERROR_MAX_RETRIES}회째)`, done: i, total: products.length, current: p.model });
          continue;
        }

        siteBlockCount++;
        if (data.blockType !== "restricted" || retries >= maxRetries) {
          const detail = data.note ? ` (${data.note})` : "";
          await giveUp(data.blockType === "restricted"
            ? `${site.name}가 접속을 계속 제한하고 있습니다 (${p.model}). ${maxRetries}번 자동 재시도(${retryWaitMin}분 간격)해봤지만 안 풀려서 멈췄습니다.${detail}`
            : data.blockType === "login"
              ? `${site.name}가 로그인을 요구합니다 (${p.model}). 크롬에서 ${site.name}에 로그인한 뒤 다시 실행하세요. 열린 탭에 보안 확인 화면이 떠 있으면 로그인하면 사라집니다.${detail}`
              : `${site.name}가 보안 확인을 요구합니다 (${p.model}). 열린 탭에서 확인을 마친 뒤 다시 실행하세요.${detail}`);
          break;
        }
        retries++;
        for (let waited = 0; waited < retryWaitMs && !cancelRequested && !siteAbort; waited += 15000) {
          const remain = formatRemain(retryWaitMs - waited);
          await setSiteStatus(site.name, { phase: `접속 제한 — ${remain} 후 자동 재시도 (${retries}/${maxRetries}회째)`, done: i, total: products.length, current: p.model });
          await sleep(Math.min(15000, retryWaitMs - waited));
        }
        if (cancelRequested) { stopReason = "cancelled"; break; }
        if (siteAbort) { stopReason = "aborted"; break; }
      }
      if (stopReason) break;

      // url: 재검색으로 찾았으면 그 검색 주소(보고서의 검색 링크가 실제로 매물을 찾은 검색을 가리키게), retried: 재검색을 해본 단계 이름들
      itemsByIndex[i] = { items: data.items || [], source: data.source || "-", note: data.note || "", url: data.searchUrl || null, retried: data.retried || [] };
      await sleep(delayMs);
    }
    if (tabState.id != null) { try { await chrome.tabs.remove(tabState.id); } catch (_) {} }
    const doneCount = itemsByIndex.filter(Boolean).length;
    await setSiteStatus(site.name, {
      phase: stopReason === "cancelled" ? "중단됨" : stopReason === "blocked" ? "차단됨" : stopReason === "aborted" ? "다른 사이트 실패로 중단" : "완료",
      done: doneCount, total: products.length, current: "",
    });
    return { site, stopReason, itemsByIndex, blockCount: siteBlockCount, done: doneCount, error: siteError };
  }

  const siteRuns = await Promise.all(SITES.map(runSite));

  const blockCounts = Object.fromEntries(siteRuns.map((r) => [r.site.name, r.blockCount])); // 사이트별 차단 횟수
  const blockCount = siteRuns.reduce((sum, r) => sum + r.blockCount, 0); // 합계 (하위 호환용)
  // 사이트별로 어디까지 갔고 왜 멈췄는지 — 보고서 상단 경고 띠(siteFailureNotes)와 카드에 씀
  const siteStatus = Object.fromEntries(siteRuns.map((r) => [r.site.name,
    { done: r.done, total: products.length, stopReason: r.stopReason, error: r.error || "" }]));

  const cancelled = siteRuns.some((r) => r.stopReason === "cancelled");
  const incompleteSites = siteRuns.filter((r) => r.stopReason === "blocked").map((r) => r.site.name);
  const stopReason = cancelled ? "cancelled" : (incompleteSites.length ? "blocked" : null);

  // 두 사이트 중 하나라도 도달한 마지막 모델까지만 보고서에 포함 (둘 다 아예 못 간 꼬리는 제외)
  let lastReached = -1;
  for (let i = 0; i < products.length; i++) {
    if (siteRuns.some((r) => r.itemsByIndex[i] != null)) lastReached = i;
  }

  const results = [];
  for (let i = 0; i <= lastReached; i++) {
    const p = products[i];
    let allItems = [];
    let totalFound = 0;
    const sourceParts = [];
    const noteParts = [];
    const siteUrls = [];
    const searchRetries = []; // 재검색을 해봤지만 못 찾은 단계 이름("브랜드 없이", "랭킹순") — 상태 글자에 "…재검색에도 없음"으로 보임
    for (const siteRun of siteRuns) {
      const entry = siteRun.itemsByIndex[i];
      const url = (entry && entry.url) || siteRun.site.buildUrl(p.brand || "", p.model);
      siteUrls.push({ name: siteRun.site.name, url });
      if (entry) {
        if (entry.retried && entry.retried.length && !entry.url) searchRetries.push(...entry.retried);
        allItems = allItems.concat(entry.items.map((it) => ({ ...it, site: siteRun.site.name }))); // 같은 매물의 경로별 가격 구분용
        totalFound += entry.items.length;
        sourceParts.push(`${siteRun.site.name}:${entry.source}`);
        if (entry.note) noteParts.push(`${siteRun.site.name}: ${entry.note}`);
      } else {
        sourceParts.push(`${siteRun.site.name}:미조회`);
      }
    }
    allItems = applyAppCoupon(allItems, appCoupon); // 설정을 켰을 때만 스마트스토어 매물 판매가에서 앱 첫구매 쿠폰을 뺌
    const { matched, rejected } = filterItems(allItems, p.model, { excludeWords, modelExclude: p.exclude, basePrice: p.basePrice, accessoryPriceRatio, naverPayBaseRate });
    const below = matched.filter((it) => it.price < p.basePrice);
    const pointBelow = matched.filter((it) => isPointBelow(it, p.basePrice)).sort(byRealPrice); // 실질가 오름차순(매니아 11.02 요청 2번)
    // 제외어 때문에 걸러졌는데 가격은 기준가 미만이었던 것 — 확인 차 보고서에 참고로 남겨둠
    // (filterItems 가 가격대로 이미 "부속품 단독판매로 보이는 것"만 걸러주므로, 여기 남는 건 대체로 진짜 제외 대상)
    const flaggedExcluded = rejected
      .filter((r) => r.reason.startsWith("제외어:") && r.item.price && r.item.price < p.basePrice)
      .sort((a, b) => a.item.price - b.item.price); // 기준가 미만 판매처 표와 동일하게 가격순 정렬
    results.push({
      ...p, url: siteUrls.map((s) => s.url).join(" / "), siteUrls,
      extractOk: allItems.length > 0, source: sourceParts.join(" / "), note: noteParts.join(" / "),
      totalFound, rejectedCount: rejected.length, searchRetries,
      // 제외된 상품도 간추려 남김 — "매칭 상품 없음"인 모델이 검색에서 뭘 받았고 왜 빠졌는지 보고서 모델별 상세에서 볼 수 있게
      // (2026-11-01 매니아 요청 4번). 보고서 저장 용량을 생각해 모델당 REJECTED_KEEP 개까지만, 필요한 칸만.
      rejected: rejected.slice(0, REJECTED_KEEP).map(({ item, reason }) => ({
        name: item.name || "", price: item.price ?? null, mall: item.mall || "", link: item.link || "", site: item.site || "", reason })),
      matched, below, pointBelow, flaggedExcluded,
      lowest: matched[0] || null,
    });
  }

  // 가격 조회가 끝까지 간 경우에만 실제 판매자 확인 — 중단/실패한 실행은 어차피 결과가 불완전함
  let sellerLookup = null;
  if (stopReason == null && settings.sellerLookup !== false) {
    try { sellerLookup = await lookupSellers(results, settings); }
    catch (e) { console.warn("판매자 확인 실패", e); sellerLookup = { total: 0, done: 0, cached: 0, failed: 0, notes: [String(e && e.message)] }; }
  }

  const report = {
    createdAt: new Date().toISOString(), durationSec: Math.round((Date.now() - startedAt) / 1000),
    sheets, naverPayBaseRate, appCoupon: appCoupon.enabled ? { maxWon: appCoupon.maxWon, ratePct: appCoupon.ratePct } : null, cancelled: stopReason != null, stopReason, siteStatus,
    productCount: products.length, skipped, results, summary: summarize(applyMyVendors(results, settings.myVendors)), blockCount, blockCounts,
    sellerLookup, myVendors: settings.myVendors || "", vendorGroups: settings.vendorGroups || "",
  };
  await chrome.storage.local.set({ lastReport: report }); // 사용자가 중단한 경우도 "지난 보고서 열기"로 나중에 확인할 수 있게 저장은 해둠

  // 사용자가 직접 중단한 경우는 의도적으로 멈춘 것이므로 CSV 다운로드/보고서 탭을 자동으로 띄우지 않음.
  // 한 사이트 실패로 전체를 멈춘 경우(siteAbort)는 반쪽 데이터라 CSV 는 안 만들고, 보고서 탭만 열어
  // 상단 경고 띠로 상황을 알림. continueOnSiteFailure 로 나머지를 끝까지 돌린 경우는 예전처럼 둘 다 만듦.
  let csvFailed = [];
  if (stopReason !== "cancelled") {
    let saveParam = "";
    if (!siteAbort) {
      const stamp = formatStamp();
      try {
        csvFailed = await downloadReportCsvs(report, stamp);
      } catch (e) { console.warn("CSV 다운로드 실패", e); csvFailed = [`전체 (${(e && e.message) || e})`]; }
      saveParam = `?save=${stamp}`; // 보고서 탭이 열리면서 같은 폴더에 보고서.html 도 저장함 (report.js)
    }
    await chrome.tabs.create({ url: chrome.runtime.getURL("src/report.html") + saveParam });
  }
  const phase = stopReason === "cancelled" || siteAbort ? "중단됨" : "완료";
  const failMsg = siteAbort
    ? `${siteAbort.msg}\n→ 다른 사이트 조회도 함께 중단했습니다. 결과가 불완전하니 잠시 후 다시 실행하세요. (보고서 탭 상단 안내 참고, CSV 는 만들지 않음)`
    : incompleteSites.length
      ? `${incompleteSites.join(", ")} 조회가 끝까지 못 갔습니다 — 그 사이트의 가격·포인트가 빠져 있습니다. 보고서 상단 안내를 확인하세요.`
      : csvFailed.length
        ? `CSV 파일을 저장하지 못했습니다: ${csvFailed.join(", ")}. 보고서 탭의 "CSV 다시 받기"를 눌러 보세요.`
        : null;
  await setStatus({
    running: false, phase, done: results.length, total: products.length, current: "",
    incompleteSites: stopReason === "blocked" ? incompleteSites : [],
    error: failMsg,
  });
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "run") { run().catch((e) => setStatus({ running: false, error: String(e) })); sendResponse({ ok: true }); }
  else if (msg.type === "cancel") {
    cancelRequested = true;
    // run() 이 실제로 멈추기까지 시간이 걸릴 수 있고, 최악의 경우(서비스워커가 이미 죽어서 아무도 안 보고 있는 상태)엔
    // 영영 반응이 없을 수 있으니, 버튼을 누르면 일단 바로 뭔가 바뀐 걸로 표시함. run() 이 살아있었다면 곧 자기 몫의
    // 최종 상태로 다시 덮어씀.
    setStatus({ running: false, phase: "중단됨" });
    sendResponse({ ok: true });
  }
  return false;
});

// 서비스 워커가 (재시작이든, 죽었다 다시 깨어난 것이든) 새로 뜰 때마다 이 top-level 코드가 실행됨 —
// 이 시점엔 이 인스턴스에 진행 중인 run() 이 있을 수 없으므로, storage 에 running:true 가 남아있다면
// 그건 이전 인스턴스가 도중에 죽어서 못 정리한 stale 상태라는 뜻. 자동으로 정리해서 "중단 버튼이 반응 없음" 방지.
//
// 확장을 새로고침(또는 업데이트)했거나 크롬을 새로 켠 경우에는 지난 실행의 표시("중단됨 네이버 18/80 …")를 지우고
// 팝업을 처음 화면으로 되돌림(2026-09-28 요청 — 새로고침해도 예전 중단 내역이 계속 떠 있어서 헷갈림).
// 지난 보고서(lastReport)와 판매자 기록(sellerCache)은 그대로 둠 — "지난 보고서 열기"는 계속 됨.
// 서비스 워커가 쉬다가 다시 깨어난 것뿐이면 이 두 이벤트는 오지 않으므로, 그때는 아래의 stale 정리만 함.
let bootReset = false;
const resetStatus = () => { bootReset = true; return chrome.storage.local.set({ status: {} }); };
chrome.runtime.onInstalled.addListener(resetStatus);
chrome.runtime.onStartup.addListener(resetStatus);

// 위 이벤트가 먼저 처리되도록 잠깐 뒤에 확인 — 초기화한 상태 위에 "예기치 않게 중단" 문구를 덧쓰지 않게
// **runInFlight 도 봐야 함(2026-11-01)**: 서비스 워커가 잠들어 있다가 팝업의 "가격 조회 실행" 클릭으로 깨어나면, 이 타이머가
// 돌기 전에 run() 이 이미 running:true 를 써 둔 상태라 이걸 죽은 실행의 흔적으로 오판해 running:false 와 "예기치 않게 중단"
// 문구를 덮어썼음 — 조회는 멀쩡히 계속 도는데 팝업만 틀린 말을 함(매니아 10.19 요청 3번). 이 인스턴스에 run() 이 돌고 있으면
// stale 일 리 없으니 건너뜀.
setTimeout(async () => {
  if (bootReset || runInFlight) return;
  const { status } = await chrome.storage.local.get("status");
  if (bootReset || runInFlight || !(status && status.running)) return;
  setStatus({ running: false, error: "실행이 예기치 않게 중단됐습니다 (브라우저/확장 재시작 등). 다시 실행해주세요." });
}, 500);
