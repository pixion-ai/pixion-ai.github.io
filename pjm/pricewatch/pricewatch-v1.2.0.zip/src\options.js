import { normalizeSheets } from "./lib/sheet.js";
import { DEFAULT_WARN_TEMPLATE } from "./lib/seller.js";

const FIELDS = ["excludeWords", "tabMode", "delayMs", "maxRetries"];
const DEFAULTS = {
  sheets: [], sheetUrl: "", tabMode: "reuseHidden", delayMs: 1000, maxRetries: 3, retryWaitMs: 4 * 60 * 1000,
  accessoryPriceRatio: 0.5, naverPayBaseRate: 1, catalogLookup: true, continueOnSiteFailure: false, sellerLookup: true, myVendors: "", vendorGroups: "", warnTemplate: DEFAULT_WARN_TEMPLATE,
  excludeWords: "중고, 리퍼, 램프, 리모컨, 리모콘, 렌즈, 마운트, 브라켓, 브래킷, 케이스, 가방, 필터, 스크린, 케이블, 천장, 거치대, 스탠드, 부품, 교체용, 호환, 렌탈, 대여, 약정, 리스",
};

// background.js 가 실제로 쪼개는 방식과 똑같이 세야 함(쉼표/줄바꿈 구분, 빈 항목 제외)
const countExcludeWords = (text) => text.split(/[,\n]/).map((s) => s.trim()).filter(Boolean).length;
const updateExcludeCount = () => {
  document.getElementById("excludeCount").textContent = `(${countExcludeWords(document.getElementById("excludeWords").value)}개)`;
};
document.getElementById("excludeWords").addEventListener("input", updateExcludeCount);

const sheetList = document.getElementById("sheetList");
const sheetsFromScreen = () => normalizeSheets({
  sheets: Array.from(sheetList.querySelectorAll(".sheet-row")).map((row) => ({
    name: row.querySelector(".name").value, url: row.querySelector(".url").value,
    enabled: row.querySelector(".enabled").checked,
  })),
});
const flashSaved = (text = "저장됨") => {
  const el = document.getElementById("saved");
  el.textContent = text;
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 1500);
};
// 체크 박스: 체크된 시트만 조회함. 주소를 지우지 않고 잠시 빼둘 때 씀. 새로 추가한 줄은 켜진 채로 시작.
// 다른 항목과 똑같이 "저장"을 눌러야 적용됨 — 2026-11-01 매니아가 "하나만 체크해도 둘 다 조회된다"고 해서(10.19 요청 5번) 체크를
// 바꾸는 즉시 저장하게 했다가, "한 화면에서 어떤 건 바로 저장되고 어떤 건 버튼을 눌러야 하면 더 헷갈린다, 실수가 확실하면
// 저장을 누르라고 말해 주면 된다"는 사용자 판단으로 같은 날 되돌림. 대신 팝업 첫 화면에 "조회할 시트: …"를 보여줘 실행 전에
// 저장된 상태를 확인할 수 있게 함(popup.js).
const addSheetRow = (sheet = { name: "", url: "", enabled: true }) => {
  const row = document.createElement("div");
  row.className = "sheet-row";
  row.innerHTML = '<input type="checkbox" class="enabled" title="체크된 시트만 조회합니다"><input class="name" placeholder="이름 (예: PJM 자사)"><input class="url" placeholder="https://docs.google.com/spreadsheets/d/…/edit#gid=0"><button type="button" class="remove">삭제</button>';
  const check = row.querySelector(".enabled");
  check.checked = sheet.enabled !== false;
  const dim = () => row.classList.toggle("off", !check.checked);
  check.onchange = dim;
  dim();
  row.querySelector(".name").value = sheet.name;
  row.querySelector(".url").value = sheet.url;
  row.querySelector(".remove").onclick = () => {
    row.remove();
    if (!sheetList.children.length) addSheetRow();
  };
  sheetList.appendChild(row);
};
document.getElementById("addSheet").onclick = () => addSheetRow();

chrome.storage.sync.get(DEFAULTS).then((s) => {
  const sheets = normalizeSheets(s);
  (sheets.length ? sheets : [{ name: "", url: "" }]).forEach((sh) => addSheetRow(sh));
  FIELDS.forEach((f) => (document.getElementById(f).value = s[f] ?? DEFAULTS[f]));
  document.getElementById("retryWaitMin").value = Math.round((s.retryWaitMs ?? DEFAULTS.retryWaitMs) / 60000);
  document.getElementById("accessoryRatioPct").value = Math.round((s.accessoryPriceRatio ?? DEFAULTS.accessoryPriceRatio) * 100);
  document.getElementById("naverPayBaseRate").value = s.naverPayBaseRate ?? DEFAULTS.naverPayBaseRate;
  document.getElementById("catalogLookup").checked = s.catalogLookup !== false;
  document.getElementById("continueOnSiteFailure").checked = s.continueOnSiteFailure === true;
  document.getElementById("sellerLookup").checked = s.sellerLookup !== false;
  document.getElementById("myVendors").value = s.myVendors || "";
  document.getElementById("vendorGroups").value = s.vendorGroups || "";
  document.getElementById("warnTemplate").value = s.warnTemplate || DEFAULT_WARN_TEMPLATE;
  updateExcludeCount();
});

document.getElementById("save").onclick = async () => {
  const s = {};
  FIELDS.forEach((f) => (s[f] = document.getElementById(f).value.trim()));
  s.sheets = sheetsFromScreen();
  s.delayMs = Number(s.delayMs) || 0;
  s.maxRetries = Number(s.maxRetries) || 0;
  s.retryWaitMs = (Number(document.getElementById("retryWaitMin").value) || 4) * 60000;
  const pct = Number(document.getElementById("accessoryRatioPct").value);
  s.accessoryPriceRatio = Number.isFinite(pct) ? pct / 100 : 0.5; // 0%도 유효한 값이라 || 로 처리하면 안 됨
  const rateText = document.getElementById("naverPayBaseRate").value.trim();
  s.naverPayBaseRate = rateText !== "" && Number.isFinite(Number(rateText)) ? Number(rateText) : DEFAULTS.naverPayBaseRate; // 빈칸은 기본값, 0은 유효한 값
  s.catalogLookup = document.getElementById("catalogLookup").checked;
  s.continueOnSiteFailure = document.getElementById("continueOnSiteFailure").checked;
  s.sellerLookup = document.getElementById("sellerLookup").checked;
  s.myVendors = document.getElementById("myVendors").value.trim();
  s.vendorGroups = document.getElementById("vendorGroups").value.trim();
  s.warnTemplate = document.getElementById("warnTemplate").value.trim() || DEFAULT_WARN_TEMPLATE; // 비우면 기본 문구로
  document.getElementById("warnTemplate").value = s.warnTemplate;
  await chrome.storage.sync.set(s);
  await chrome.storage.sync.remove(["sheetUrl", "brand"]); // 예전 버전 설정 정리 — 시트 1개(sheetUrl), 브랜드 검색어(brand: 이제 시트의 브랜드 열로)

  // 이름이 비어 있던 행은 "시트N"으로 채워졌으니 화면도 저장된 값으로 다시 그림
  sheetList.replaceChildren();
  (s.sheets.length ? s.sheets : [{ name: "", url: "" }]).forEach((sh) => addSheetRow(sh));

  flashSaved();
};

document.getElementById("version").textContent = "Pixion Inc. 최저가 감시 · v" + chrome.runtime.getManifest().version;
