// G마켓·옥션 상품 페이지에 주입해 판매자(입점 업체) 정보를 읽는 스크립트 (IIFE 반환값이 결과). 2026-09-28 추가.
// 두 장터는 같은 회사(주식회사 지마켓)라 상품 페이지 구조가 같아서 이 파일 하나를 같이 씀.
// background.js 의 lookupSellers 가 기준가 미만 매물에 한해 아래 주소를 열고 호출:
//   G마켓  https://item.gmarket.co.kr/Item?goodscode=<상품번호>
//   옥션   https://itempage3.auction.co.kr/DetailView.aspx?itemno=<상품번호>
//
// 실제 구조(2026-09-28 사용자가 실제 크롬 콘솔로 떠 준 결과 — 밖에서는 봇 확인 화면(403)만 받아서 볼 수 없었음):
//   상품명 위:   span.text__seller > a.link__seller  "(주)프로젝터매니아"
//                href = minishop.gmarket.co.kr/<판매자id> (G마켓) / stores.auction.co.kr/<판매자id> (옥션)
//   아래 상점 정보: div.shop-infobox > strong.shop-title > a  (G마켓에만 있음. 위가 없을 때 대신 씀)
//   교환/반품 탭:  ul.list__exchange-data > li  "상호명 : …" "대표자 : …" "연락처 : …" "사업자등록번호 : …" "사업장소재지 : …"
//                  — 전자상거래법상 공개되는 사업자 정보라 보안문자 없이 보임. 탭의 id 는 두 장터가 달라서
//                  (#vip-tab_exchange / #vip_tab_exchange) 목록의 클래스로 찾음. "사업자 등록번호"처럼 띄어 쓴 곳도 있어
//                  라벨은 공백을 떼고 비교.
// 탭 내용은 눌러야 보이지만 DOM 에는 처음부터 들어 있음(사용자 결과에서 스크롤만으로 읽힘).
(() => {
  const text = (el) => (el && el.textContent ? el.textContent.replace(/\s+/g, " ").trim() : "");
  const attr = (el, name) => (el ? (el.getAttribute ? el.getAttribute(name) : el[name]) || "" : "");
  const url = location.href;
  const market = /auction\.co\.kr/.test(url) ? "옥션" : "G마켓";

  let link = document.querySelector("a.link__seller");
  if (!text(link)) {
    const title = document.querySelector("strong.shop-title");
    link = title ? title.querySelector("a") : null;
  }
  const name = text(link);

  if (!name) {
    // 봇 확인 화면: "고객님의 사이트 내 활동이 봇의 동작과 유사해 보입니다 … 간단한 봇 확인 절차" (2026-09-27 curl 응답으로 확인)
    const head = `${document.title || ""} ${text(document.body).slice(0, 600)}`;
    if (/봇\s*확인|봇의 동작|사용자 활동 검토|보안문자|자동입력\s*방지/.test(head)) {
      return { ok: false, blocked: true, blockType: "captcha", url, seller: null, note: `${market}이 봇 확인을 요구함 — 열린 탭에서 확인을 마치면 다음 실행부터 조회됨` };
    }
    return { ok: false, blocked: false, url, seller: null, note: "판매자 이름을 찾지 못함 (판매 종료된 상품이거나 페이지 구조가 바뀜)" };
  }

  // "라벨 : 값" 줄들 — 첫 번째 콜론에서 나눔(주소·번호 안의 콜론은 값에 남김)
  const info = {};
  for (const list of document.querySelectorAll("ul.list__exchange-data")) {
    for (const li of list.querySelectorAll("li")) {
      const t = text(li);
      const i = t.indexOf(":");
      if (i > 0) info[t.slice(0, i).replace(/\s+/g, "")] = t.slice(i + 1).trim();
    }
  }
  const m = attr(link, "href").match(/(?:minishop\.gmarket\.co\.kr|stores\.auction\.co\.kr)\/([\w-]+)/);
  return {
    ok: true, blocked: false, url, source: `${market} 판매자 정보`,
    seller: {
      name, company: info["상호명"] || "", bizType: "", ceo: info["대표자"] || "",
      phone: info["연락처"] || "", bizNo: info["사업자등록번호"] || "", address: info["사업장소재지"] || "",
      sellerId: m ? m[1] : "",
    },
    note: "",
  };
})();
