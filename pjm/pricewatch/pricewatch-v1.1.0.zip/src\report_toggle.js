// 보고서의 표 행 펼치기/접기 + 제목 옆 "전체 펼치기/접기" 버튼 + 업체별 안내 문구 "복사" 버튼.
// 확장 안의 보고서 페이지(report.html)와, 다운로드 폴더에 같이 저장되는 독립 HTML 파일(보고서.html) 양쪽에서
// 이 파일 하나를 씀 — report.js 가 저장할 때 이 파일의 글자를 그대로 <script> 로 박아 넣음.
// 그래서 여기서는 chrome.* API 나 module import 를 쓰면 안 되고, 내용이 그려지기 전에 실행돼도 되도록
// document 에 이벤트 위임만 걸어둠.
//
// "전체 펼치기"(.toggle-all)는 자기가 들어 있는 <section> 안의 행만 다룸 — 모델별 현황과 업체별 위반 내역이
// 각자 버튼을 갖고 있어서(2026-09-27), 한쪽 버튼이 다른 표까지 펼치면 안 됨.
(() => {
  const rowsIn = (scope) => Array.from(scope.querySelectorAll("tr.expandable"));
  const detailOf = (row) => document.getElementById(row.dataset.toggle);
  const updateLabel = (scope) => {
    const btn = scope.querySelector(".toggle-all");
    if (!btn) return;
    const rows = rowsIn(scope);
    const allOpen = rows.length > 0 && rows.every((row) => { const d = detailOf(row); return d && !d.hidden; });
    btn.textContent = allOpen ? "전체 접기" : "전체 펼치기";
  };

  const copyText = async (text, area) => {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (_) {
      // 파일로 저장한 보고서 등 clipboard API 가 막힌 환경 — 문구 영역을 선택해서 옛 방식으로 복사
      const range = document.createRange();
      range.selectNodeContents(area);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      try { return document.execCommand("copy"); } catch (_e) { return false; }
    }
  };

  document.addEventListener("click", async (e) => {
    if (!e.target.closest("#content")) return;
    if (e.target.closest("a")) return; // 링크(네이버/다나와 등) 클릭은 그냥 링크만 열리게, 행 토글은 안 함

    const copyBtn = e.target.closest(".copy-msg");
    if (copyBtn) {
      const area = document.getElementById(copyBtn.dataset.target);
      if (!area) return;
      const ok = await copyText(area.value != null ? area.value : area.innerText, area);
      const label = copyBtn.dataset.label || copyBtn.textContent;
      copyBtn.dataset.label = label;
      copyBtn.textContent = ok ? "복사됨 ✓" : "복사 실패 — 문구를 직접 선택해 복사하세요";
      setTimeout(() => { copyBtn.textContent = label; }, 1800);
      return;
    }

    const all = e.target.closest(".toggle-all");
    if (all) {
      const scope = all.closest("section") || document;
      const open = all.textContent !== "전체 접기";
      rowsIn(scope).forEach((row) => {
        const d = detailOf(row);
        if (!d) return;
        d.hidden = !open;
        row.classList.toggle("open", open);
      });
      updateLabel(scope);
      return;
    }
    const row = e.target.closest("tr[data-toggle]");
    if (!row) return;
    const detail = detailOf(row);
    if (!detail) return;
    detail.hidden = !detail.hidden;
    row.classList.toggle("open", !detail.hidden);
    updateLabel(row.closest("section") || document);
  });
})();
