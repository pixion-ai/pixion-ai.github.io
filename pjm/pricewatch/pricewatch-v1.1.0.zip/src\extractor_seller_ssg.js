// SSG.COM·신세계몰·이마트몰 상품 페이지에 주입해 판매자(위탁판매자) 정보를 읽는 스크립트 (IIFE 반환값이 결과).
// 2026-09-28 추가. 세 곳은 같은 회사(에스에스지닷컴)의 같은 상품 페이지라 이 파일 하나를 같이 씀.
// background.js 의 lookupSellers 가 기준가 미만 매물에 한해 https://www.ssg.com/item/itemView.ssg?itemId=<상품번호> 를 열고 호출.
//
// 실제 구조(2026-09-28 사용자가 실제 크롬 콘솔·화면 캡처로 떠 준 결과 — 밖에서는 "접속이 잠시 제한되었습니다"(403)만 받음):
//   상품 이미지 아래:  div.cdtl_brand_store … strong.brand_store_info_tit > a
//                      "프로젝터매니아(projectorman 판매자스토어"  href=/sellerhome/<판매자id>/main.ssg
//                      — 상점 이름이 잘려 나오고 뒤에 "판매자스토어"가 붙어서, 이름으로는 아래 표의 업체명을 우선 씀
//   페이지 아래 "위탁판매자정보":  클래스 없는 <table> 의 tr > th(div.in "업체명") / td "(주)프로젝터매니아",
//                      "주소", "통신판매번호", "사업자등록번호" — 대표자·연락처는 없음
//   맨 아래 회사 정보(span.cmfooter_corp_tx "대표자: 최택원", "사업자등록번호: 870-88-…")는 SSG 자신의 것이라 읽으면 안 됨
//   — 그래서 표 안에 "업체명" 제목이 있는 것만 읽음.
// SSG 가 직접 파는 상품(이마트 등)은 위탁판매자정보가 없음 → "못 찾음"으로 돌려줌.
(() => {
  const text = (el) => (el && el.textContent ? el.textContent.replace(/\s+/g, " ").trim() : "");
  const attr = (el, name) => (el ? (el.getAttribute ? el.getAttribute(name) : el[name]) || "" : "");
  const url = location.href;

  // "위탁판매자정보" 표 — th 에 "업체명"이 있는 표를 찾아 제목-값을 읽음
  let info = null;
  for (const table of document.querySelectorAll("table")) {
    const rows = {};
    for (const tr of table.querySelectorAll("tr")) {
      let label = null;
      for (const cell of Array.from(tr.children)) {
        const tag = String(cell.tagName || "").toLowerCase();
        if (tag === "th") label = text(cell).replace(/\s+/g, "");
        else if (tag === "td" && label) { rows[label] = text(cell); label = null; }
      }
    }
    if (rows["업체명"]) { info = rows; break; }
  }

  let storeName = "", sellerId = "";
  const title = document.querySelector("strong.brand_store_info_tit");
  const link = title ? title.querySelector("a") : null;
  if (link) {
    storeName = text(link).replace(/판매자\s*스토어/g, "").trim();
    const m = attr(link, "href").match(/\/sellerhome\/([\w-]+)\//);
    if (m) sellerId = m[1];
  }

  const name = (info && info["업체명"]) || storeName;
  if (!name) {
    const head = `${document.title || ""} ${text(document.body).slice(0, 600)}`;
    if (/접속이 잠시 제한|비정상적인 접근|자동화된 환경|보안문자|자동입력\s*방지/.test(head)) {
      return { ok: false, blocked: true, blockType: "restricted", url, seller: null, note: "SSG가 접속을 제한함" };
    }
    return { ok: false, blocked: false, url, seller: null, note: "위탁판매자 정보를 찾지 못함 (SSG가 직접 파는 상품이거나, 판매 종료, 또는 페이지 구조가 바뀜)" };
  }
  const dash = (v) => (v && v !== "-" ? v : ""); // 비어 있는 칸은 "-" 로 나옴
  return {
    ok: true, blocked: false, url, source: "SSG 위탁판매자정보",
    seller: {
      name, company: dash(info && info["업체명"]), bizType: "", ceo: "", phone: "",
      bizNo: dash(info && info["사업자등록번호"]), address: dash(info && info["주소"]), sellerId,
    },
    note: "",
  };
})();
