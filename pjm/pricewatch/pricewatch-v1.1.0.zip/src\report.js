import { buildCsv, buildExcludedCsv, buildDetailCsv, summarize, formatStamp, formatDuration, realPrice, siteFailureNotes } from "./lib/report.js";
import { isPointBelow } from "./lib/match.js";
import { groupViolations, applyMyVendors, buildWarningMessage, buildVendorCsv, isOpenMarket, directSellerOf, DEFAULT_WARN_TEMPLATE } from "./lib/seller.js";

const won = (n) => (n == null ? "-" : Number(n).toLocaleString("ko-KR"));
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const link = (href, text) => (href ? `<a href="${esc(href)}" target="_blank" rel="noopener">${esc(text)}</a>` : esc(text));
// "가격비교(카탈로그)"/"다나와"는 실제 판매처 이름이 아니라 여러 판매처를 모은 집계 페이지라, 진짜 판매처와
// 구분되게 표시하고(회색 기울임 + 안내), 클릭하면 그 집계 페이지(=진짜 판매처가 나오는 곳)로 가도록 링크를 걺.
const AGGREGATE_MALLS = new Set(["가격비교(카탈로그)", "다나와"]);
// 이 매물이 위반(기준가 미만 또는 포인트 반영 시 기준가 미만)인지 — 내 업체 매물은 위반으로 안 봄
const violating = (it, basePrice) => basePrice != null && !it.mine && (it.price < basePrice || isPointBelow(it, basePrice));
// basePrice: 그 모델의 기준가. 위반 매물인지 가려 "판매자 미확인" 표시 여부를 정하는 데 씀
const mallCell = (it, basePrice = null) => {
  if (!it) return "-";
  const isAgg = AGGREGATE_MALLS.has(it.mall);
  const label = isAgg ? `${it.mall} ↗` : it.mall;
  if (isAgg) return `<span class="mall-agg" title="개별 판매처가 아닌 집계 페이지입니다. 눌러서 실제 판매처를 확인하세요.">${link(it.link, label)}</span>`;
  // 크게 보이는 글자는 항상 "누가 파는가"(판매자), 그 아래 작은 글자는 "어디서 파는가"(장터) — 2026-09-28 사용자 요청.
  // 처음엔 오픈마켓 매물을 "11번가"(크게) + "판매자: 조은폰영상"(작게)으로 그렸는데, 스마트스토어 매물은 판매자 이름이
  // 크게 나오니 정작 더 중요한 판매자가 오픈마켓 쪽에서만 작게 보였음. 그래서 어느 쪽이든 판매자를 크게 통일하고,
  // 장터(11번가/쿠팡/스마트스토어 …)는 아래에 작게 적음. 자체 쇼핑몰처럼 장터가 따로 없으면 아래 줄을 안 씀.
  const mine = it.mine ? '<div class="ch">내 업체 — 위반으로 세지 않음</div>' : "";
  if (it.seller && it.seller.name) {
    const tip = esc([it.seller.company, it.seller.ceo && `대표 ${it.seller.ceo}`, it.seller.phone && `연락처 ${it.seller.phone}`].filter(Boolean).join(" · "));
    return `<span title="${tip}">${link(it.link, it.seller.name)}</span><div class="ch">${esc(it.mall)}</div>${mine}`;
  }
  const direct = directSellerOf(it.mall); // 현대Hmall 처럼 운영사가 직접 파는 것으로 보는 장터
  if (direct) return `${link(it.link, direct.name)}<div class="ch">${esc(it.mall)}</div>${mine}`;
  // "판매자 미확인"은 위반 매물에만 적음 — 판매자는 위반 매물만 확인하므로, 이상 없는 매물에까지 적으면 군더더기
  if (isOpenMarket(it.mall)) return `${link(it.link, it.mall)}${violating(it, basePrice) ? '<div class="ch">판매자 미확인</div>' : ""}${mine}`;
  const platform = platformOf(it);
  return `${link(it.link, it.mall)}${platform ? `<div class="ch">${platform}</div>` : ""}${mine}`;
};
// 스마트스토어 매물인지 — 링크(경로별 링크 포함) 중에 네이버 스토어 주소가 있으면. 다나와에서만 찾은 매물은 링크가
// 다나와 주소라 알 수 없어서 아무것도 안 적음.
const platformOf = (it) => {
  const links = [it.link, ...(it.prices || []).map((c) => c.link)].filter(Boolean);
  return links.some((l) => /\/\/(m\.)?(smartstore|brand)\.naver\.com\//.test(l)) ? "스마트스토어" : "";
};
// 판매가 칸: 가장 싼 경로의 가격 + 경로가 둘 이상이거나 네이버 묶음 가격이 섞였으면 경로별 가격을 작게 덧붙임
const priceCell = (it) => {
  const chs = it.prices || [];
  if (chs.length < 2 && !it.bundle) return won(it.price);
  // 사이트명과 가격을 한 줄에 붙여 씀 — 칸이 좁아 둘이 따로 접히면 세로로 길어져서 보기 나쁨.
  // "네이버로 진입 717,750"처럼 적음 — "(네이버) 717,750"은 무슨 뜻인지(판매처가 네이버? 가격 출처?) 알기 어렵다는 지적
  // (2026-09-28). 같은 매물이라도 어느 가격비교 사이트를 거쳐 들어가느냐에 따라 값이 달라진다는 뜻.
  const lines = chs.map((c) => `${esc(c.site)}${c.bundle ? " 묶음으로" : "로"} 진입 ${won(c.price)}`).join("<br>");
  return `${won(it.price)}<div class="ch" title="같은 매물도 어느 가격비교 사이트를 거쳐 들어가느냐에 따라 가격이 다릅니다. 가장 싼 값으로 판정합니다.">${lines}</div>`;
};
// 업체 이름 아래 작게 덧붙이는 사업자 정보 — 장터가 공개한 것만(11번가: 상호·대표자 / G마켓: 연락처·사업자번호까지)
const vendorInfo = (v) => [v.company && v.company !== v.name ? v.company : "", v.ceo && `대표 ${v.ceo}`, v.phone && `연락처 ${v.phone}`, v.bizNo && `사업자 ${v.bizNo}`].filter(Boolean).join(" · ");
// 시트 "제외어" 열에 적은 단어가 있으면 모델명 아래 작게 표시 — 이 행에서 왜 어떤 상품이 빠졌는지 알 수 있게
const excludeNote = (x) => (x.exclude && x.exclude.length ? `<div class="ch">제외: ${esc(x.exclude.join(", "))}</div>` : "");
// 실질가 아래 작은 글자: "판매가 1,020,000 / 추가 적립 30,000 (기본 1% 제외)".
// 표기 이력(2026-09-28): "추가 포인트 9,000" → 1%인데 왜 잡혔는지 헷갈림 → "적립 18,000 − 기본 9,000" → 설정이 1%라는 걸
// 알아야 읽히고 직관적이지 않음 → 지금 표기. 추가 적립액(=실질가를 낮춘 금액)을 그대로 보여주고, 기본 적립은 뺀 값이라는
// 것과 그 비율을 괄호로 덧붙임. rate 는 그 보고서를 만들 때의 네이버페이 기본 적립률(%).
const pointLines = (price, point, rate) =>
  `판매가 ${won(price)}<br>추가 적립 ${won(point)}${rate != null ? ` (기본 ${rate}% 제외)` : ""}`;
// 보낼 문구 안의 주소를 누를 수 있는 링크로 — 보내기 전에 해당 매물을 바로 열어볼 수 있게. 복사할 때는 글자만 복사됨
// (카카오톡 등은 붙여 넣은 주소를 알아서 링크로 만들어 줌).
const linkify = (text) => esc(text).replace(/https?:\/\/[^\s<]+/g, (u) => `<a href="${u}" target="_blank" rel="noopener">${u}</a>`);
// 포인트가 붙은 경로(네이버)의 링크 — 실질가는 그 경로에서 살 때 가격
const pointLink = (it) => ((it.prices || []).find((c) => c.price === it.pointPrice) || it).link;

document.getElementById("version").textContent = "Pixion Inc. 최저가 감시 · v" + chrome.runtime.getManifest().version;

const { lastReport: stored } = await chrome.storage.local.get("lastReport");
// 안내 문구의 틀과 "내 업체 이름"은 저장된 보고서가 아니라 지금 설정값을 씀 — 설정을 고치고 보고서를 새로고침하면
// 다시 조회하지 않아도 바로 반영됨. 내 업체 매물은 기준가 미만에서 빠지므로 요약(카드)도 여기서 다시 계산.
const { warnTemplate, myVendors } = await chrome.storage.sync.get({ warnTemplate: DEFAULT_WARN_TEMPLATE, myVendors: "" });
const r = stored ? { ...stored, results: applyMyVendors(stored.results, myVendors) } : stored;
if (r) r.summary = summarize(r.results);

// 이 탭을 보고 있는 동안 새 실행이 끝나 보고서가 바뀌면(저장은 항상 하나만) 자동으로 갈아끼우지 않고 위에 안내만 띄움 —
// 보던 내용이 조용히 바뀌는 것보다 낫고, 새 결과는 어차피 새 탭으로 따로 열림.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !changes.lastReport) return;
  const nv = changes.lastReport.newValue;
  if (!nv || (r && nv.createdAt === r.createdAt)) return;
  const el = document.getElementById("newer");
  el.hidden = false;
  el.innerHTML = `새 보고서가 생겼습니다 (${esc(new Date(nv.createdAt).toLocaleString("ko-KR"))} 생성). 지금 보고 있는 것은 이전 보고서입니다. <button id="reload">새 보고서 보기</button>`;
  el.querySelector("#reload").onclick = () => location.reload();
});

if (!r) {
  document.getElementById("content").innerHTML = '<p class="muted">아직 생성된 보고서가 없습니다. 확장 아이콘을 눌러 "가격 조회 실행"을 눌러주세요.</p>';
} else {
  const s = r.summary;
  const modelCount = r.results.length < r.productCount ? `${r.results.length}/${r.productCount}개 모델 (중단됨)` : `${r.productCount}개 모델`;
  const stopNote = r.stopReason === "blocked" ? " · 접속 차단으로 중단"
    : r.stopReason === "cancelled" ? " · 사용자가 중단" : "";
  // 시트가 하나뿐이면(또는 시트 정보가 없는 옛 보고서면) "시트" 열은 군더더기라 숨김
  const sheetNames = [...new Set([...r.results, ...(r.skipped || [])].map((x) => x.sheet).filter(Boolean))];
  const multiSheet = sheetNames.length > 1;
  const sheetNote = multiSheet ? ` · 시트 ${sheetNames.length}개` : "";
  const rateNote = r.naverPayBaseRate != null ? ` · 포인트는 네이버페이 기본 적립 ${r.naverPayBaseRate}% 제외` : "";
  document.getElementById("meta").textContent =
    `${new Date(r.createdAt).toLocaleString("ko-KR")} 생성${r.brand ? ` · 브랜드 "${r.brand}"` : ""}${sheetNote} · ${modelCount} · 소요시간 ${formatDuration(r.durationSec)}${rateNote}${stopNote}`;

  // 한 사이트라도 끝까지 못 갔으면 맨 위에 빨간 경고 띠 — 그 사이트의 가격/포인트가 빠진 반쪽 결과임을 분명히 알림
  const failNotes = siteFailureNotes(r);
  document.getElementById("banner").innerHTML = failNotes.length
    ? `<div class="fail-banner"><b>⚠ 이 보고서는 불완전합니다</b><ul>${failNotes.map((n) => `<li>${esc(n)}</li>`).join("")}</ul>
       <div class="fail-hint">잠시 후(접속 제한은 보통 몇 분 안에 풀림) 다시 실행하세요.</div></div>`
    : "";

  // 사이트별 차단 횟수(blockCounts)가 있으면 "네이버 1회" / "다나와 0회"를 줄바꿔서, 옛 보고서(그 필드 없음)는 합계만 표시.
  // 끝까지 못 간 사이트는 옆에 "조회 실패"/"중단"을 덧붙임 — 차단 0회여도 실패했을 수 있어서(탭 오류 경로).
  const siteTag = (name) => {
    const s = (r.siteStatus || {})[name];
    if (!s) return "";
    if (s.stopReason === "blocked") return ' <span class="fail-tag">조회 실패</span>';
    if (s.stopReason === "aborted" || s.stopReason === "cancelled") return ' <span class="fail-tag">중단</span>';
    return "";
  };
  const blockValue = r.blockCounts
    ? `<div class="block-lines">${Object.entries(r.blockCounts).map(([name, n]) => `<b>${esc(name)} ${n}회${siteTag(name)}</b>`).join("")}</div>`
    : `<b>${r.blockCount || 0}회</b>`;
  const pointSellers = s.pointBelowSellerCount || 0;
  document.getElementById("cards").innerHTML = `
    <div class="card ${s.belowModelCount ? "alert" : ""}"><span>기준가 미만 발견 모델</span><b>${s.belowModelCount}</b></div>
    <div class="card ${s.belowSellerCount ? "alert" : ""}"><span>기준가 미만 판매처(건)</span><b>${s.belowSellerCount}</b></div>
    <div class="card ${pointSellers ? "point" : ""}"><span>포인트 반영 시 기준가 미만(건)</span><b>${pointSellers}</b></div>
    <div class="card"><span>조회 모델</span><b>${s.checked}</b></div>
    <div class="card"><span>매칭 상품 없음</span><b>${s.noDataCount}</b></div>
    <div class="card ${r.blockCount || failNotes.length ? "alert" : ""}"><span>접속 거부(차단) 발생</span>${blockValue}</div>`;

  let html = "";

  // 모델별 현황 — 이 보고서의 핵심. 전체 모델을 한 줄씩, 시트에 있는 순서 그대로 보여주고
  // 기준가 미만(빨강) / 포인트 반영 시 기준가 미만(주황) / 제외어로 걸러졌지만 기준가 미만이었던 상품(회색)이 있는
  // 행을 누르면 그 모델의 해당 목록이 바로 아래 펼쳐짐.
  const flaggedTotal = r.results.reduce((n, x) => n + (x.flaggedExcluded ? x.flaggedExcluded.length : 0), 0);
  const pointModels = s.pointBelowModelCount || 0;
  const anyExpandable = r.results.some((x) => x.below.length || (x.pointBelow || []).length || (x.flaggedExcluded && x.flaggedExcluded.length));
  html += `<section><h2>모델별 현황 <span class="count">(${r.results.length}개 중 기준가 미만 ${s.belowModelCount}개${pointModels ? `, 포인트 반영 시 미만 ${pointModels}개` : ""}${flaggedTotal ? `, 제외어 적용 ${flaggedTotal}건` : ""})</span>${anyExpandable ? '<button class="link-btn toggle-all" id="toggleAll">전체 펼치기</button>' : ""}</h2>`;
  if (!s.belowModelCount && !pointModels && !flaggedTotal) html += '<div class="empty-ok">✓ 기준가 미만인 모델이 없습니다.</div>';
  // 판매처 열은 2026-09-28 에 뺌 — "모델별 현황에서는 의미가 없고 눌러서 들어갔을 때만 의미가 있다, 화면에는 꼭 필요한
  // 정보만"이라는 요청. 최저가를 누가 파는지는 행을 펼치면 나오는 목록의 첫 줄에 있음.
  // 시트/구분/검색 칸과 상태 배지는 줄바꿈 금지(nw) — 창이 넓어도 "자사모/델"처럼 두 줄로 접혀 보기 나빴음.
  // 상태는 배지 단위로만 줄이 바뀜.
  html += `<div class="table-wrap"><table class="models"><tr>${multiSheet ? '<th class="nw">시트</th>' : ""}<th class="nw">구분</th><th>모델</th><th class="num">기준가</th><th class="num">최저가</th><th>상태</th><th class="nw">검색</th></tr>`;
  r.results.forEach((x, i) => {
    const isBelow = x.below.length > 0;
    const points = x.pointBelow || [];
    const hasPoint = points.length > 0;
    const flagged = x.flaggedExcluded || [];
    const hasFlagged = flagged.length > 0;
    const expandable = isBelow || hasPoint || hasFlagged;

    // filterItems 가 가격대로 부속품성 제외를 이미 걸러주므로, 여기 남는 제외 건은 대체로 진짜 제외 대상 —
    // 기준가 미만이 없을 때는 "이상 없음"을 우선 보여주고 제외어 적용 건수는 참고용 괄호로만 덧붙임.
    let state;
    if (isBelow || hasPoint) {
      state = [
        isBelow && `<span class="st diff">기준가 미만 ${x.below.length}건</span>`,
        hasPoint && `<span class="st pt-badge">포인트 반영 시 미만 ${points.length}건</span>`,
        hasFlagged && `<span class="st note-badge">제외어 적용 ${flagged.length}건</span>`,
      ].filter(Boolean).join('<span class="sep">·</span>');
    } else if (hasFlagged) {
      state = `<span class="st">이상 없음</span><span class="sep">·</span><span class="st note-badge">제외어 적용 ${flagged.length}건</span>`;
    } else {
      state = x.matched.length ? '<span class="st">이상 없음</span>' : `<span class="muted">${esc(x.note || "매칭 상품 없음")}</span>`;
    }

    const rowClass = [expandable && "expandable", isBelow && "below", !isBelow && hasPoint && "pointed",
      !isBelow && !hasPoint && hasFlagged && "flagged"].filter(Boolean).join(" ");
    const searchLinks = (x.siteUrls || []).map((s2) => link(s2.url, s2.name)).join(" · ");
    html += `<tr class="${rowClass}" ${expandable ? `data-toggle="mrow-${i}"` : ""}>
      ${multiSheet ? `<td class="nw">${esc(x.sheet)}</td>` : ""}<td class="nw">${esc(x.group)}</td><td>${esc(x.model)}${excludeNote(x)}</td><td class="num">${won(x.basePrice)}</td>
      <td class="num">${x.lowest ? won(x.lowest.price) : "-"}</td>
      <td class="state">${expandable ? '<span class="chevron">▸</span>' : ""}${state}</td>
      <td class="nw">${searchLinks}</td></tr>`;

    if (expandable) {
      let sub = "";
      if (isBelow) {
        sub += `<div class="sub-block"><div class="sub-label">기준가 미만 판매처</div><div class="table-wrap sub">
          <table><tr><th class="num">판매가</th><th class="num">차액</th><th>판매처</th><th>상품명</th></tr>
          ${x.below.map((it) => `<tr class="below"><td class="num">${priceCell(it)}</td><td class="num diff">${won(it.price - x.basePrice)}</td><td>${mallCell(it, x.basePrice)}</td><td>${link(it.link, it.name)}</td></tr>`).join("")}
          </table></div></div>`;
      }
      if (hasPoint) {
        sub += `<div class="sub-block"><div class="sub-label point">포인트 반영 시 기준가 미만 — 판매가는 기준가 이상</div><div class="table-wrap sub point">
          <table><tr><th class="num">실질가</th><th class="num">차액</th><th>판매처</th><th>상품명</th></tr>
          ${points.map((it) => `<tr class="pointed"><td class="num">${won(realPrice(it))}<div class="ch">${pointLines(it.pointPrice ?? it.price, it.point, r.naverPayBaseRate)}</div></td><td class="num diff-pt">${won(realPrice(it) - x.basePrice)}</td><td>${mallCell(it, x.basePrice)}</td><td>${link(pointLink(it), it.name)}</td></tr>`).join("")}
          </table></div></div>`;
      }
      if (hasFlagged) {
        sub += `<div class="sub-block"><div class="sub-label note">제외어로 걸러짐 — 참고용</div><div class="table-wrap sub note">
          <table><tr><th class="num">판매가</th><th class="num">차액</th><th>제외 사유</th><th>상품명</th></tr>
          ${flagged.map((r2) => `<tr><td class="num">${won(r2.item.price)}</td><td class="num diff">${won(r2.item.price - x.basePrice)}</td><td class="muted">${esc(r2.reason)}</td><td>${link(r2.item.link, r2.item.name)}</td></tr>`).join("")}
          </table></div></div>`;
      }
      html += `<tr class="mrow-detail" id="mrow-${i}" hidden><td colspan="${multiSheet ? 7 : 6}">${sub}</td></tr>`;
    }
  });
  html += "</table></div></section>";

  // ---- 업체별 위반 내역 (2026-09-27) — 위반 업체에 연락할 때 쓰는 표. 행을 펼치면 보낼 문구와 매물 목록이 나옴.
  const vendors = groupViolations(r.results); // r.results 는 이미 내 업체 매물을 뺀 것(applyMyVendors)
  const mineRemoved = r.results.reduce((n, x) => n + (x.mineRemoved || 0), 0);
  const mineNote = mineRemoved ? ` 내 업체(${myVendors.trim()}) 매물 ${mineRemoved}건은 위반으로 세지 않았습니다.` : "";
  if (vendors.length || mineRemoved) {
    const unidentified = vendors.filter((v) => !v.identified);
    const sl = r.sellerLookup;
    const lookupNote = sl && sl.total
      ? `오픈마켓 판매자 확인 ${sl.total}건 중 ${sl.done}건${sl.cached ? ` (저장해 둔 정보 ${sl.cached}건)` : ""}${sl.failed ? `, 실패 ${sl.failed}건` : ""}${sl.cancelled ? ", 중단됨" : ""}`
      : "";
    html += `<section style="margin-top:30px"><h2>업체별 위반 내역 <span class="count">(${vendors.length}곳${unidentified.length ? `, 판매자 미확인 ${unidentified.length}곳` : ""})</span><button class="link-btn toggle-all">전체 펼치기</button></h2>`;
    html += `<p class="sec-note">기준가 미만과 포인트 반영 시 기준가 미만 매물을 판매 업체별로 묶었습니다. 행을 누르면 그 업체에 보낼 안내 문구가 나오고, <b>문구 복사</b>를 누른 뒤 카카오톡 등에 붙여 넣으면 됩니다. 문구의 틀은 설정에서 바꿀 수 있습니다.${esc(mineNote)}${lookupNote ? ` <span class="muted">${esc(lookupNote)}</span>` : ""}</p>`;
    html += `<div class="table-wrap"><table class="models"><tr><th>업체</th><th class="nw">판매처</th><th>위반</th><th class="num">모델 수</th><th class="num">가장 큰 차액</th></tr>`;
    vendors.forEach((v, i) => {
      const belowN = v.items.filter((x) => x.kind === "below").length;
      const pointN = v.items.length - belowN;
      const malls = [...new Set(v.items.map((x) => x.mall))];
      const models = new Set(v.items.map((x) => x.model)).size;
      const worst = Math.min(...v.items.map((x) => x.diff));
      const counts = [
        belowN && `<span class="st diff">기준가 미만 ${belowN}건</span>`,
        pointN && `<span class="st pt-badge">포인트 반영 시 미만 ${pointN}건</span>`,
      ].filter(Boolean).join('<span class="sep">·</span>');
      const who = v.identified
        ? `${esc(v.name)}${vendorInfo(v) ? `<div class="ch">${esc(vendorInfo(v))}</div>` : ""}`
        : `<span class="muted">${esc(v.name)} — 판매자 미확인</span><div class="ch">${isOpenMarket(v.mall) ? "오픈마켓 입점 업체를 확인하지 못했습니다. 링크를 열어 확인하세요." : ""}</div>`;
      html += `<tr class="expandable ${belowN ? "below" : "pointed"}" data-toggle="vrow-${i}">
        <td>${who}</td><td class="nw">${esc(malls.slice(0, 3).join(", "))}${malls.length > 3 ? ` 외 ${malls.length - 3}` : ""}</td>
        <td class="state">${counts}</td><td class="num">${models}</td><td class="num diff">${won(worst)}</td></tr>`;
      const msg = buildWarningMessage(v, { template: warnTemplate, date: r.createdAt });
      html += `<tr id="vrow-${i}" class="mrow-detail" hidden><td colspan="5">
        <div class="msg-box">
          <div class="msg-head"><span class="sub-label note">보낼 문구</span><button class="copy-msg" data-target="vmsg-${i}">문구 복사</button></div>
          <div class="msg-text" id="vmsg-${i}">${linkify(msg)}</div>
        </div>
        <div class="table-wrap sub vitems${belowN ? "" : " point"}"><table><tr><th class="num">판매가</th><th class="num">차액</th><th>모델 · 판매처</th><th>상품명</th></tr>
        ${v.items.map((x) => `<tr class="${x.kind === "point" ? "pointed" : "below"}"><td class="num">${won(x.realPrice)}${x.kind === "point" ? `<div class="ch">${pointLines(x.price, x.point, r.naverPayBaseRate)}</div>` : ""}</td><td class="num ${x.kind === "point" ? "diff-pt" : "diff"}">${won(x.diff)}</td><td>${esc(x.model)}<div class="ch">${multiSheet ? `${esc(x.sheet)} · ` : ""}${esc(x.mall)} · 기준가 ${won(x.basePrice)}</div></td><td>${link(x.link, x.name)}</td></tr>`).join("")}
        </table></div></td></tr>`;
    });
    html += "</table></div></section>";
  }

  // 모델별 상세(모델별 매칭 전체 목록, OK 상품까지 다 보임)는 위와 상당 부분 겹치는 정보라
  // 기본은 접어두고, 필요할 때만(매칭이 이상하다 싶을 때) 펼쳐서 보게 함.
  html += `<details class="collapsible"><summary>모델별 상세 <span class="count">(검색된 상품 전체 목록)</span></summary><div class="inner">`;
  for (const x of r.results) {
    html += `<details class="model"><summary>${multiSheet ? `${esc(x.sheet)} · ` : ""}<b>${esc(x.model)}</b>${x.exclude && x.exclude.length ? ` <span class="muted">(제외: ${esc(x.exclude.join(", "))})</span>` : ""}&nbsp; 매칭 ${x.matched.length}개 / 검색결과 ${x.totalFound}개 (제외 ${x.rejectedCount}) · 출처 ${esc(x.source || "-")}</summary>`;
    if (!x.matched.length) html += '<p class="muted">없음</p>';
    else {
      html += `<div class="table-wrap"><table><tr><th class="num">가격</th><th class="num">추가 포인트</th><th>판매처</th><th>상품명</th></tr>`;
      for (const it of x.matched) {
        const cls = it.mine ? "" : it.price < x.basePrice ? "below" : isPointBelow(it, x.basePrice) ? "pointed" : ""; // 내 업체 매물은 위반 표시 안 함
        const pt = it.point > 0 ? won(it.point) : it.point == null && it.bundle ? '<span class="muted" title="네이버 묶음 목록에서만 확인돼 포인트를 알 수 없습니다">확인 불가</span>' : "-";
        html += `<tr class="${cls}"><td class="num">${priceCell(it)}</td><td class="num">${pt}</td><td>${mallCell(it, x.basePrice)}</td><td>${link(it.link, it.name)}</td></tr>`;
      }
      html += "</table></div>";
    }
    html += "</details>";
  }
  html += "</div></details>";

  // 시트에서 건너뛴 행 — 없으면 표시 안 함
  if (r.skipped && r.skipped.length) {
    html += `<section style="margin-top:30px"><h2>시트에서 건너뛴 행 <span class="count">(${r.skipped.length}개)</span></h2>`;
    html += `<div class="table-wrap"><table><tr>${multiSheet ? "<th>시트</th>" : ""}<th>행</th><th>내용</th><th>사유</th></tr>`;
    for (const k of r.skipped) html += `<tr>${multiSheet ? `<td>${esc(k.sheet)}</td>` : ""}<td>${k.row}</td><td>${esc(k.raw)}</td><td class="muted">${esc(k.reason)}</td></tr>`;
    html += "</table></div></section>";
  }

  document.getElementById("content").innerHTML = html;
  // 행 펼치기/접기 동작은 report_toggle.js (독립 HTML 파일과 공유) 가 document 위임으로 처리함

  // 이 화면을 그대로 파일 하나로 저장 — theme.css 와 report_toggle.js 를 안에 박아 넣어 확장 없이도 열리고
  // 행 펼치기도 되게 함. 버튼·"새 보고서" 안내처럼 확장 안에서만 뜻이 있는 요소(data-export="drop")는 뺌.
  const buildStandaloneHtml = async () => {
    const [theme, toggle] = await Promise.all([
      fetch(chrome.runtime.getURL("src/theme.css")).then((x) => x.text()),
      fetch(chrome.runtime.getURL("src/report_toggle.js")).then((x) => x.text()),
    ]);
    const doc = document.documentElement.cloneNode(true);
    doc.querySelectorAll("script, link[rel=stylesheet], [data-export=drop]").forEach((el) => el.remove());
    const style = document.createElement("style");
    style.textContent = theme;
    doc.querySelector("head").prepend(style);
    const script = document.createElement("script");
    script.textContent = toggle;
    doc.querySelector("body").append(script);
    return "<!doctype html>\n" + doc.outerHTML;
  };
  const saveHtml = async (stamp) => {
    const url = URL.createObjectURL(new Blob([await buildStandaloneHtml()], { type: "text/html" }));
    try {
      await chrome.downloads.download({ url, filename: `pricewatch/${stamp}/보고서.html`, saveAs: false });
    } finally {
      setTimeout(() => URL.revokeObjectURL(url), 60000);
    }
  };
  // background 가 실행 직후 보고서 탭을 열 때 ?save=<실행시각> 을 붙여주면 CSV 3개와 같은 폴더에 보고서.html 도 저장.
  // 주소에서 바로 지워서 새로고침할 때 또 저장되지 않게 함.
  const saveStamp = new URLSearchParams(location.search).get("save");
  if (saveStamp) {
    history.replaceState(null, "", location.pathname);
    saveHtml(saveStamp).catch((e) => console.warn("보고서 HTML 저장 실패", e));
  }
  document.getElementById("html").onclick = () => saveHtml(formatStamp(new Date(r.createdAt))).catch((e) => alert("저장 실패: " + e.message));

  document.getElementById("csv").onclick = async () => {
    // 원래 실행 때와 같은 3개 파일(기준가 미만/제외어 확인/모델별 상세)을 같은 규칙으로 재생성.
    // 폴더명은 "지금 다시 받는 시각"이 아니라 이 보고서가 실제로 생성됐던 시각(report.createdAt) 기준 —
    // 그래야 원래 실행 때 만들어졌을 폴더명과 같아져서 헷갈리지 않음.
    const stamp = formatStamp(new Date(r.createdAt));
    const folder = `pricewatch/${stamp}`;
    const files = [
      [`${folder}/기준가미만.csv`, buildCsv(r)],
      [`${folder}/제외어확인.csv`, buildExcludedCsv(r)],
      [`${folder}/모델별상세.csv`, buildDetailCsv(r)],
      [`${folder}/업체별위반.csv`, buildVendorCsv(r, { myVendors })],
    ];
    for (const [filename, csv] of files) {
      await chrome.downloads.download({ url: "data:text/csv;charset=utf-8," + encodeURIComponent("﻿" + csv), filename, saveAs: false });
    }
  };
}
