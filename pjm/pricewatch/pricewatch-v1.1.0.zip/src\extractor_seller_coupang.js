// 쿠팡 상품 페이지에 주입해 판매자(입점 업체) 정보를 읽는 스크립트 (IIFE 반환값이 결과). 2026-09-28 추가.
// background.js 의 lookupSellers 가 기준가 미만 매물에 한해
//   https://www.coupang.com/vp/products/<상품번호>?itemId=<옵션>&vendorItemId=<판매자별 매물>
// 을 열고 호출. 쿠팡은 한 상품을 여러 판매자가 파는 구조라 vendorItemId 에 따라 표시되는 판매자가 달라짐.
//
// 실제 구조(2026-09-28 사용자가 실제 크롬 콘솔로 떠 준 결과 — 밖에서는 403 만 받아서 볼 수 없었음):
//   가격 아래:  div.seller-info 안의 a[href="https://shop.coupang.com/vid/<판매자id>?…"]
//               글자는 "이제이테크판매자 상품 보러가기" — 이름 뒤에 버튼 글자가 붙어 나와서 떼어냄
//   페이지 아래 "판매자 정보": div.product-seller 안 table.prod-delivery-return-policy-table
//               th "상호/대표자" → td "이제이테크 / 김은주",  th "사업자번호", "사업장 소재지", "e-mail", "연락처" …
//               같은 클래스의 표가 배송·반품 안내에도 쓰여서 div.product-seller 안의 것만 읽음.
//   아래쪽 표는 스크롤해야 채워질 수 있음(사용자는 끝까지 스크롤한 뒤 떴음) — 확장은 탭을 스크롤하지 않으므로
//   없을 수 있고, 그때는 위쪽 이름만으로 결과를 돌려줌(상호·대표자·연락처는 빈 칸).
(() => {
  const text = (el) => (el && el.textContent ? el.textContent.replace(/\s+/g, " ").trim() : "");
  const attr = (el, name) => (el ? (el.getAttribute ? el.getAttribute(name) : el[name]) || "" : "");
  const url = location.href;

  let name = "", sellerId = "";
  for (const box of document.querySelectorAll("div.seller-info")) {
    for (const a of box.querySelectorAll("a")) {
      const m = attr(a, "href").match(/shop\.coupang\.com\/vid\/(\w+)/);
      if (!m) continue;
      sellerId = m[1];
      name = text(a).replace(/판매자\s*상품\s*보러가기/g, "").trim();
      break;
    }
    if (name) break;
  }

  // "판매자 정보" 표 — 한 줄에 제목(th)-값(td)이 한 쌍 또는 두 쌍
  const info = {};
  for (const wrap of document.querySelectorAll("div.product-seller")) {
    for (const tr of wrap.querySelectorAll("tr")) {
      let label = null;
      for (const cell of Array.from(tr.children)) {
        const tag = String(cell.tagName || "").toLowerCase();
        if (tag === "th") label = text(cell).replace(/\s+/g, "");
        else if (tag === "td" && label) { info[label] = text(cell); label = null; }
      }
    }
  }
  // "이제이테크 / 김은주" → 상호 / 대표자
  const [company = "", ceo = ""] = String(info["상호/대표자"] || "").split("/").map((s) => s.trim());
  if (!name) name = company;

  if (!name) {
    const head = `${document.title || ""} ${text(document.body).slice(0, 600)}`;
    if (/Access Denied|접근이 (거부|차단|제한)|비정상적인 접근|보안문자|자동입력\s*방지|로봇이 아닙니다/i.test(head)) {
      return { ok: false, blocked: true, blockType: "restricted", url, seller: null, note: "쿠팡이 접속을 막음" };
    }
    return { ok: false, blocked: false, url, seller: null, note: "판매자 표시를 찾지 못함 (쿠팡이 직접 파는 상품이거나, 판매 종료, 또는 페이지 구조가 바뀜)" };
  }
  return {
    ok: true, blocked: false, url, source: "쿠팡 판매자 정보",
    seller: {
      name, company, bizType: "", ceo,
      phone: info["연락처"] || "", bizNo: info["사업자번호"] || "", address: info["사업장소재지"] || "",
      email: info["e-mail"] || info["이메일"] || "", sellerId,
    },
    note: "",
  };
})();
