import { normalizeSheets } from "./lib/sheet.js";
import { DEFAULT_WARN_TEMPLATE } from "./lib/seller.js";

const FIELDS = ["excludeWords", "tabMode", "delayMs", "maxRetries"];
const DEFAULTS = {
  sheets: [], sheetUrl: "", tabMode: "reuseHidden", delayMs: 1000, maxRetries: 3, retryWaitMs: 4 * 60 * 1000,
  accessoryPriceRatio: 0.5, naverPayBaseRate: 1, catalogLookup: true, continueOnSiteFailure: false, sellerLookup: true, myVendors: "", warnTemplate: DEFAULT_WARN_TEMPLATE,
  excludeWords: "중고, 리퍼, 램프, 리모컨, 리모콘, 렌즈, 마운트, 브라켓, 브래킷, 케이스, 가방, 필터, 스크린, 케이블, 천장, 거치대, 스탠드, 부품, 교체용, 호환, 렌탈, 대여, 약정, 리스",
};

// background.js 가 실제로 쪼개는 방식과 똑같이 세야 함(쉼표/줄바꿈 구분, 빈 항목 제외)
const countExcludeWords = (text) => text.split(/[,\n]/).map((s) => s.trim()).filter(Boolean).length;
const updateExcludeCount = () => {
  document.getElementById("excludeCount").textContent = `(${countExcludeWords(document.getElementById("excludeWords").value)}개)`;
};
document.getElementById("excludeWords").addEventListener("input", updateExcludeCount);

const sheetList = document.getElementById("sheetList");
// 체크 박스: 체크된 시트만 조회함. 주소를 지우지 않고 잠시 빼둘 때 씀. 새로 추가한 줄은 켜진 채로 시작.
const addSheetRow = (sheet = { name: "", url: "", enabled: true }) => {
  const row = document.createElement("div");
  row.className = "sheet-row";
  row.innerHTML = '<input type="checkbox" class="enabled" title="체크된 시트만 조회합니다"><input class="name" placeholder="이름 (예: PJM 자사)"><input class="url" placeholder="https://docs.google.com/spreadsheets/d/…/edit#gid=0"><button type="button" class="remove">삭제</button>';
  const check = row.querySelector(".enabled");
  check.checked = sheet.enabled !== false;
  const dim = () => row.classList.toggle("off", !check.checked);
  check.onchange = dim;
  dim();
  row.querySelector(".name").value = sheet.name;
  row.querySelector(".url").value = sheet.url;
  row.querySelector(".remove").onclick = () => {
    row.remove();
    if (!sheetList.children.length) addSheetRow();
  };
  sheetList.appendChild(row);
};
document.getElementById("addSheet").onclick = () => addSheetRow();

chrome.storage.sync.get(DEFAULTS).then((s) => {
  const sheets = normalizeSheets(s);
  (sheets.length ? sheets : [{ name: "", url: "" }]).forEach((sh) => addSheetRow(sh));
  FIELDS.forEach((f) => (document.getElementById(f).value = s[f] ?? DEFAULTS[f]));
  document.getElementById("retryWaitMin").value = Math.round((s.retryWaitMs ?? DEFAULTS.retryWaitMs) / 60000);
  document.getElementById("accessoryRatioPct").value = Math.round((s.accessoryPriceRatio ?? DEFAULTS.accessoryPriceRatio) * 100);
  document.getElementById("naverPayBaseRate").value = s.naverPayBaseRate ?? DEFAULTS.naverPayBaseRate;
  document.getElementById("catalogLookup").checked = s.catalogLookup !== false;
  document.getElementById("continueOnSiteFailure").checked = s.continueOnSiteFailure === true;
  document.getElementById("sellerLookup").checked = s.sellerLookup !== false;
  document.getElementById("myVendors").value = s.myVendors || "";
  document.getElementById("warnTemplate").value = s.warnTemplate || DEFAULT_WARN_TEMPLATE;
  updateExcludeCount();
});

document.getElementById("save").onclick = async () => {
  const s = {};
  FIELDS.forEach((f) => (s[f] = document.getElementById(f).value.trim()));
  s.sheets = normalizeSheets({
    sheets: Array.from(sheetList.querySelectorAll(".sheet-row")).map((row) => ({
      name: row.querySelector(".name").value, url: row.querySelector(".url").value,
      enabled: row.querySelector(".enabled").checked,
    })),
  });
  s.delayMs = Number(s.delayMs) || 0;
  s.maxRetries = Number(s.maxRetries) || 0;
  s.retryWaitMs = (Number(document.getElementById("retryWaitMin").value) || 4) * 60000;
  const pct = Number(document.getElementById("accessoryRatioPct").value);
  s.accessoryPriceRatio = Number.isFinite(pct) ? pct / 100 : 0.5; // 0%도 유효한 값이라 || 로 처리하면 안 됨
  const rateText = document.getElementById("naverPayBaseRate").value.trim();
  s.naverPayBaseRate = rateText !== "" && Number.isFinite(Number(rateText)) ? Number(rateText) : DEFAULTS.naverPayBaseRate; // 빈칸은 기본값, 0은 유효한 값
  s.catalogLookup = document.getElementById("catalogLookup").checked;
  s.continueOnSiteFailure = document.getElementById("continueOnSiteFailure").checked;
  s.sellerLookup = document.getElementById("sellerLookup").checked;
  s.myVendors = document.getElementById("myVendors").value.trim();
  s.warnTemplate = document.getElementById("warnTemplate").value.trim() || DEFAULT_WARN_TEMPLATE; // 비우면 기본 문구로
  document.getElementById("warnTemplate").value = s.warnTemplate;
  await chrome.storage.sync.set(s);
  await chrome.storage.sync.remove(["sheetUrl", "brand"]); // 예전 버전 설정 정리 — 시트 1개(sheetUrl), 브랜드 검색어(brand: 이제 시트의 브랜드 열로)

  // 이름이 비어 있던 행은 "시트N"으로 채워졌으니 화면도 저장된 값으로 다시 그림
  sheetList.replaceChildren();
  (s.sheets.length ? s.sheets : [{ name: "", url: "" }]).forEach((sh) => addSheetRow(sh));

  const el = document.getElementById("saved");
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 1500);
};

document.getElementById("version").textContent = "Pixion Inc. 최저가 감시 · v" + chrome.runtime.getManifest().version;
