// 11번가 상품 페이지에 주입해 "판매자정보" 표를 읽는 스크립트 (IIFE 반환값이 결과). 2026-09-27 추가.
// background.js 의 lookupSellers 가 기준가 미만 매물에 한해 https://www.11st.co.kr/products/<상품번호> 를 열고 호출.
//
// 실제 구조(2026-09-27 curl 로 받은 페이지로 확인):
//   <table class="prdc_detail_table"><caption>판매자정보 테이블</caption>
//     <tr><th>판매자</th><td>프로젝터매니아</td><th>상호명</th><td>주식회사 프로젝터매니아</td></tr>
//     <tr><th>사업자구분</th><td>법인사업자</td><th>대표자</th><td>정석호</td></tr>
// 같은 클래스의 표가 페이지에 여러 개(상품정보 제공고시 등)라 caption 으로 가려냄.
// 연락처·사업자등록번호는 "상세정보 확인" 버튼 뒤 보안문자(캡차) 화면에 있어서 읽지 않음 — 그건 사람이 직접 확인할 몫.
(() => {
  const text = (el) => (el && el.textContent ? el.textContent.replace(/\s+/g, " ").trim() : "");
  const url = location.href;

  let table = null;
  for (const t of document.querySelectorAll("table.prdc_detail_table")) {
    if (/판매자\s*정보/.test(text(t.querySelector("caption")))) { table = t; break; }
  }

  if (!table) {
    // 표가 없을 때만 차단 여부를 봄 — 정상 페이지에도 "보안문자" 같은 글자가 다른 자리에 있을 수 있어서
    const head = `${document.title || ""} ${text(document.body).slice(0, 600)}`;
    if (/보안문자|자동입력\s*방지|로봇이 아닙니다/.test(head)) {
      return { ok: false, blocked: true, blockType: "captcha", url, seller: null, note: "11번가가 보안 확인을 요구함" };
    }
    if (/비정상적인 접근|접근이 (일시적으로 )?(제한|차단)|잠시 후 다시/.test(head)) {
      return { ok: false, blocked: true, blockType: "restricted", url, seller: null, note: "11번가가 접속을 제한함" };
    }
    return { ok: false, blocked: false, url, seller: null, note: "판매자정보 표를 찾지 못함 (판매 종료된 상품이거나 페이지 구조가 바뀜)" };
  }

  // 한 줄에 제목(th)-값(td)이 두 쌍씩 있음 — 순서대로 짝지음
  const info = {};
  for (const tr of table.querySelectorAll("tr")) {
    let label = null;
    for (const cell of Array.from(tr.children)) {
      const tag = String(cell.tagName || "").toLowerCase();
      if (tag === "th") label = text(cell);
      else if (tag === "td" && label) { info[label] = text(cell); label = null; }
    }
  }
  const name = info["판매자"] || info["상호명"] || "";
  if (!name) return { ok: false, blocked: false, url, seller: null, note: "판매자정보 표에 판매자 이름이 없음" };
  return {
    ok: true, blocked: false, url, source: "11번가 판매자정보",
    seller: { name, company: info["상호명"] || "", bizType: info["사업자구분"] || "", ceo: info["대표자"] || "" },
    note: "",
  };
})();
