// 쿠팡 상품 페이지에 주입해 판매자(입점 업체) 정보를 읽는 스크립트 (IIFE 반환값이 결과). 2026-09-28 추가.
// background.js 의 lookupSellers 가 기준가 미만 매물에 한해
//   https://www.coupang.com/vp/products/<상품번호>?itemId=<옵션>&vendorItemId=<판매자별 매물>
// 을 열고 호출. 쿠팡은 한 상품을 여러 판매자가 파는 구조라 vendorItemId 에 따라 표시되는 판매자가 달라짐.
//
// 실제 구조(2026-09-28 사용자가 실제 크롬 콘솔로 떠 준 결과 — 밖에서는 403 만 받아서 볼 수 없었음):
//   가격 아래:  div.seller-info 안의 a[href="https://shop.coupang.com/vid/<판매자id>?…"]
//               글자는 "이제이테크판매자 상품 보러가기" — 이름 뒤에 버튼 글자가 붙어 나와서 떼어냄
//   페이지 아래 "판매자 정보": div.product-seller 안 table.prod-delivery-return-policy-table
//               th "상호/대표자" → td "이제이테크 / 김은주",  th "사업자번호", "사업장 소재지", "e-mail", "연락처" …
//               같은 클래스의 표가 배송·반품 안내에도 쓰여서 div.product-seller 안의 것만 읽음.
//   아래쪽 표는 스크롤해야 채워질 수 있음(사용자는 끝까지 스크롤한 뒤 떴음) — 확장은 탭을 스크롤하지 않으므로
//   없을 수 있고, 그때는 위쪽 이름만으로 결과를 돌려줌(상호·대표자·연락처는 빈 칸). 실제 실행(20260928_0101)에서는
//   쿠팡 매물 전부 상호·대표자·연락처까지 채워져 나와 스크롤 없이도 읽히는 것으로 보임.
// 페이지 모양은 세 가지: (1) 입점 업체 매물 — 위 구조, (2) 쿠팡이 파는 반품·중고 — 아래 "반품·중고 전용 페이지",
//   (3) 쿠팡이 직접 파는 새 상품(로켓배송) — 판매자 상자 없이 아래 표에 "판매자 | 쿠팡 1577-7011" 한 줄.
(() => {
  const text = (el) => (el && el.textContent ? el.textContent.replace(/\s+/g, " ").trim() : "");
  const attr = (el, name) => (el ? (el.getAttribute ? el.getAttribute(name) : el[name]) || "" : "");
  const url = location.href;

  let name = "", sellerId = "";
  for (const box of document.querySelectorAll("div.seller-info")) {
    for (const a of box.querySelectorAll("a")) {
      const m = attr(a, "href").match(/shop\.coupang\.com\/vid\/(\w+)/);
      if (!m) continue;
      sellerId = m[1];
      name = text(a).replace(/판매자\s*상품\s*보러가기/g, "").trim();
      break;
    }
    if (name) break;
  }
  const fromBox = !!name;

  // "판매자 정보" 표 — 한 줄에 제목(th)-값(td)이 한 쌍 또는 두 쌍
  const info = {};
  let directPhone = "";
  for (const wrap of document.querySelectorAll("div.product-seller")) {
    for (const tr of wrap.querySelectorAll("tr")) {
      let label = null;
      for (const cell of Array.from(tr.children)) {
        const tag = String(cell.tagName || "").toLowerCase();
        if (tag === "th") label = text(cell).replace(/\s+/g, "");
        else if (tag === "td" && label) {
          let value = text(cell);
          // 쿠팡이 직접 파는 상품(로켓배송, 2026-09-28 사용자 콘솔 결과): 판매자 상자가 없고 표가 "판매자" 한 줄뿐 —
          // <td>쿠팡<a class="prod-delivery-return-policy-table__phone-link" href="tel:…">1577-7011</a></td>
          // 글자를 그대로 읽으면 "쿠팡1577-7011" 이라 전화 링크 글자를 떼어 이름과 연락처로 나눔
          if (label === "판매자") {
            const tel = text(cell.querySelector("a")) || (value.match(/\d{2,4}-\d{3,4}(-\d{4})?$/) || [""])[0];
            if (tel) { directPhone = tel; value = value.replace(tel, "").trim(); }
          }
          info[label] = value;
          label = null;
        }
      }
    }
  }
  // "이제이테크 / 김은주" → 상호 / 대표자
  const [company = "", ceo = ""] = String(info["상호/대표자"] || "").split("/").map((s) => s.trim());

  // 반품·중고 전용 페이지 (2026-09-28 사용자 콘솔 결과로 확인): 쿠팡이 반품 재고를 직접 파는 매물은 위의 판매자 상자가
  // 없고 페이지 모양이 다름(div.used-only). 지금 연 매물의 상태는 제목 위 표식 li.offer-badge-item("반품-중"),
  // 판매자는 아래 표 table.offer-list-table 의 tr.offer-item 안 div.offer-item-seller 의 첫 칸("쿠팡"),
  // 각 줄의 상태는 span.offer-item-status-label("반품-중" / "새 상품"). 같은 표에 새 상품 줄도 같이 나오므로
  // 표식과 상태가 같은 줄의 판매자를 씀. 이런 매물은 업체의 가격 위반이 아니라서 returned 로 표시해 위반에서 뺌.
  let condition = text(document.querySelector("li.offer-badge-item"));
  const offers = [];
  for (const tr of document.querySelectorAll("tr.offer-item")) {
    const box = tr.querySelector("div.offer-item-seller");
    offers.push({ status: text(tr.querySelector("span.offer-item-status-label")), seller: text(box ? Array.from(box.children)[0] : null) });
  }
  if (fromBox) {
    condition = ""; // 판매자 상자가 있는 보통 페이지 — 표식이 있더라도 다른 매물 것일 수 있어 쓰지 않음
  } else if (offers.length) {
    const mine = offers.find((o) => condition && o.status === condition) || offers[0];
    name = mine.seller;
    if (!condition) condition = mine.status;
  }
  // 판매자 상자도 매물 표도 없으면 아래 표에서: 입점 업체는 상호, 쿠팡 직접 판매는 "판매자" 줄
  if (!name) name = company || info["판매자"] || "";
  const returned = /반품|중고|리퍼/.test(condition);

  if (!name) {
    const head = `${document.title || ""} ${text(document.body).slice(0, 600)}`;
    if (/Access Denied|접근이 (거부|차단|제한)|비정상적인 접근|보안문자|자동입력\s*방지|로봇이 아닙니다/i.test(head)) {
      return { ok: false, blocked: true, blockType: "restricted", url, seller: null, note: "쿠팡이 접속을 막음" };
    }
    return { ok: false, blocked: false, url, seller: null, note: "판매자 표시를 찾지 못함 (판매 종료된 상품이거나 페이지 구조가 바뀜)" };
  }
  return {
    ok: true, blocked: false, url, source: "쿠팡 판매자 정보",
    seller: {
      name, company, bizType: "", ceo,
      phone: info["연락처"] || directPhone, bizNo: info["사업자번호"] || "", address: info["사업장소재지"] || "",
      email: info["e-mail"] || info["이메일"] || "", sellerId,
      ...(returned ? { returned: true, condition } : {}),
    },
    note: "",
  };
})();
